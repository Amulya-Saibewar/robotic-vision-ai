"""
REFLECT dataset utilities: zarr loading, stage mappings, ground-truth labelling.
Ground truth success/failure: within each task family the clip with the MOST unique
stages defines the "full" task; any clip with fewer stages is labelled failure.
This matches the REFLECT dataset semantics (failed demonstrations stop early).
"""

import os
import re
import numpy as np
import zarr
import cv2
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

BASE_DIR = "/home/azureuser/robofail_dataset/reflect_dataset/real_data"

# Task-specific stage name maps (ordered by stage index 0..N-1)
STAGE_NAMES: Dict[str, List[str]] = {
    "appleinfridge": [
        "approach_apple", "grasp_apple", "lift_apple",
        "open_fridge", "place_in_fridge", "close_fridge", "return_home",
    ],
    "boilwater": [
        "approach_kettle", "grasp_kettle", "fill_water",
        "carry_to_stove", "place_on_stove", "turn_on_stove",
        "monitor_boiling", "turn_off_stove", "idle_complete",
    ],
    "cutcarrot": ["approach_carrot", "grasp_carrot", "cut_carrot"],
    "heatpot": ["approach_pot", "grasp_and_position", "heat_monitor"],
    "heatpotato": [
        "approach_potato", "grasp_potato", "open_microwave",
        "place_in_microwave", "close_microwave", "set_time", "start_microwave",
        "wait_stage1", "wait_stage2", "wait_stage3", "wait_stage4",
        "open_microwave2", "remove_potato", "check_temperature",
        "place_on_plate", "garnish", "complete",
    ],
    "makecoffee": [
        "approach_machine", "insert_pod_or_grounds",
        "place_cup", "start_machine", "collect_coffee",
    ],
    "putapplebowl": ["grasp_apple", "place_in_bowl"],
    "putfruitsbowl": [
        "approach_fruit1", "grasp_fruit1", "place_fruit1",
        "approach_fruit2", "grasp_fruit2", "place_fruit2",
    ],
    "putpeardrawer": [
        "approach_pear", "grasp_pear", "open_drawer", "place_in_drawer",
    ],
    "sauteecarrot": [
        "approach_carrot", "grasp_carrot", "cut_carrot",
        "heat_pan", "add_oil", "add_carrot_to_pan",
        "stir_carrot", "taste_check", "complete",
    ],
    "secureobjects": [
        "approach_obj1", "secure_obj1", "approach_obj2", "secure_obj2",
        "approach_obj3", "secure_obj3", "approach_obj4", "secure_obj4", "complete",
    ],
}

FAILURE_HINTS: Dict[str, str] = {
    "appleinfridge": "object_dropped_or_missed_placement",
    "boilwater": "missed_grasp_or_incorrect_placement",
    "cutcarrot": "missed_grasp",
    "heatpot": "missed_grasp_or_collision",
    "heatpotato": "timeout_or_execution_error",
    "makecoffee": "incorrect_placement_or_missed_action",
    "putapplebowl": "missed_grasp",
    "putfruitsbowl": "object_dropped",
    "putpeardrawer": "missed_grasp_or_joint_limit",
    "sauteecarrot": "execution_error_or_timeout",
    "secureobjects": "missed_grasp",
}


def task_family(clip_name: str) -> str:
    """Extract lowercase task family key from a clip directory name."""
    return re.sub(r"\d+$", "", clip_name).lower()


@dataclass
class ClipMeta:
    clip_name: str
    task: str
    video_path: str
    zarr_path: str
    n_unique_stages: int
    max_stage_idx: int
    stage_names: List[str]
    gt_outcome: str          # "success" | "failure"
    gt_failure_cause: Optional[str]
    gt_stages: List[Dict]    # [{"name": str, "start_s": float, "end_s": float}]
    fps: float
    duration_s: float
    n_frames: int


def _build_gt_stage_intervals(
    stages: np.ndarray,
    timestamps: np.ndarray,
    name_map: List[str],
) -> List[Dict]:
    """Compress a per-step stage array into timed intervals."""
    intervals = []
    cur = stages[0]
    start_ts = timestamps[0]
    for i in range(1, len(stages)):
        if stages[i] != cur or i == len(stages) - 1:
            end_ts = timestamps[i]
            idx = int(cur)
            sname = name_map[idx] if idx < len(name_map) else f"stage_{idx}"
            t0 = float(start_ts - timestamps[0])
            t1 = float(end_ts - timestamps[0])
            intervals.append({"name": sname, "start_s": round(t0, 2), "end_s": round(t1, 2)})
            cur = stages[i]
            start_ts = timestamps[i]
    return intervals


def load_all_clips() -> List[ClipMeta]:
    """Load metadata for all 30 REFLECT clips and assign GT labels."""
    clips_raw = []
    for d in sorted(os.listdir(BASE_DIR)):
        zarr_p = os.path.join(BASE_DIR, d, "replay_buffer.zarr")
        vid_p = os.path.join(BASE_DIR, d, "videos", "color.mp4")
        if not os.path.exists(zarr_p) or not os.path.exists(vid_p):
            continue
        z = zarr.open(zarr_p, "r")
        stages = z["data"]["stage"][:]
        timestamps = z["data"]["timestamp"][:]
        unique_stages = np.unique(stages)
        cap = cv2.VideoCapture(vid_p)
        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        n_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        cap.release()
        clips_raw.append({
            "clip_name": d,
            "task": task_family(d),
            "video_path": vid_p,
            "zarr_path": zarr_p,
            "n_unique_stages": len(unique_stages),
            "max_stage_idx": int(unique_stages.max()),
            "stages": stages,
            "timestamps": timestamps,
            "fps": fps,
            "n_frames": n_frames,
            "duration_s": n_frames / fps,
        })

    # Determine max stages per task family → used to define "full" task
    family_max: Dict[str, int] = {}
    for c in clips_raw:
        fam = c["task"]
        family_max[fam] = max(family_max.get(fam, 0), c["n_unique_stages"])

    metas = []
    for c in clips_raw:
        fam = c["task"]
        full_n = family_max[fam]
        is_success = c["n_unique_stages"] == full_n
        name_map = STAGE_NAMES.get(fam, [f"stage_{i}" for i in range(c["max_stage_idx"] + 1)])
        gt_intervals = _build_gt_stage_intervals(c["stages"], c["timestamps"], name_map)
        metas.append(ClipMeta(
            clip_name=c["clip_name"],
            task=fam,
            video_path=c["video_path"],
            zarr_path=c["zarr_path"],
            n_unique_stages=c["n_unique_stages"],
            max_stage_idx=c["max_stage_idx"],
            stage_names=name_map[:full_n],
            gt_outcome="success" if is_success else "failure",
            gt_failure_cause=FAILURE_HINTS.get(fam) if not is_success else None,
            gt_stages=gt_intervals,
            fps=c["fps"],
            duration_s=c["duration_s"],
            n_frames=c["n_frames"],
        ))
    return metas


def get_video_frames(video_path: str, target_fps: float = 4.0, max_frames: int = 128) -> List[np.ndarray]:
    """Extract frames at target_fps, capped at max_frames."""
    cap = cv2.VideoCapture(video_path)
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    step = max(1, int(src_fps / target_fps))
    indices = list(range(0, total, step))
    if len(indices) > max_frames:
        indices = [indices[int(i * (len(indices) - 1) / (max_frames - 1))] for i in range(max_frames)]
    frames = []
    for idx in indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = cap.read()
        if ret:
            frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    cap.release()
    return frames


if __name__ == "__main__":
    clips = load_all_clips()
    successes = sum(1 for c in clips if c.gt_outcome == "success")
    print(f"Loaded {len(clips)} clips: {successes} success, {len(clips)-successes} failure")
    for c in clips:
        print(f"  {c.clip_name:25s}  {c.gt_outcome:8s}  stages={c.n_unique_stages}/{len(c.stage_names)}  "
              f"dur={c.duration_s:.0f}s")
