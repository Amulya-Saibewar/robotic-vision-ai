# Vision Intelligence for Robot Task Monitoring
## REFLECT Dataset × nvidia/Cosmos-Reason2-2B

**Centific Hackathon — Problem 1**

---

## Overview

This project implements a Python-based computer vision pipeline that ingests short robot manipulation videos from the **REFLECT dataset** and uses **NVIDIA Cosmos-Reason2-2B** — a 2B-parameter Physical AI reasoning Vision Language Model (VLM) — to answer three questions for each clip:

1. **What task stages are being performed, and when?**
2. **Did the robot succeed or fail?**
3. **What caused the failure?**

The final output is machine-readable JSON suitable for a robotics monitoring dashboard, plus a Streamlit evaluation app.

---

## Dataset: REFLECT

| Property | Value |
|---|---|
| Source | [roboreflect.github.io](https://roboreflect.github.io/) |
| Path | `/home/azureuser/robofail_dataset/reflect_dataset/real_data/` |
| Total clips | **30** |
| GT success | **22** |
| GT failure | **8** |
| Format | `replay_buffer.zarr` (robot telemetry) + `videos/color.mp4` (RGB 1280×720 @ 30 fps) |
| Tasks | appleInFridge, boilWater, cutCarrot, heatPot, heatPotato, makeCoffee, putAppleBowl, putFruitsBowl, putPearDrawer, sauteeCarrot, secureObjects |

### Ground-Truth Label Strategy
External `success_condition.json` files were not bundled in the download. Ground truth is derived from the zarr telemetry:

> Within each task family (e.g. `boilWater`), the clip with the maximum number of unique stage indices defines the **full task**. Any clip with fewer stages (robot stopped early) is labelled **failure**.

---

## Model: nvidia/Cosmos-Reason2-2B

| Property | Value |
|---|---|
| HuggingFace ID | `nvidia/Cosmos-Reason2-2B` |
| Base architecture | Qwen3-VL-2B-Instruct (ViT encoder + dense LLM) |
| Parameters | 2.44 B |
| Input | Video (mp4) + Text |
| Output | Chain-of-thought text → structured JSON |
| Recommended FPS | 4 |
| GPU required | ≥ 24 GB VRAM (tested on A100 80 GB) |
| Precision | BF16 |
| License | NVIDIA Open Model License |

**Why Cosmos-Reason2-2B?**
It is purpose-built for Physical AI — spatio-temporal understanding, object interaction reasoning, physics-grounded analysis — making it ideal for robot video analysis without any fine-tuning.

---

## Project Structure

```
robofail_analysis/
├── dataset_utils.py      # zarr loading, stage name maps, GT label derivation
├── cosmos_analyzer.py    # Cosmos inference wrapper (frame sampling + JSON parsing)
├── evaluate.py           # Accuracy, Precision, Recall, F1, confusion matrix, ECE
├── run_analysis.py       # Main pipeline: process all 30 clips, save results.json
├── app.py                # Streamlit evaluation dashboard
├── challenges.txt        # 10 documented technical challenges + mitigations
├── results.json          # Generated output (produced by run_analysis.py)
└── README.md             # This file
```

---

## Output Format

Each clip produces a JSON record:

```json
{
  "video_id": "makeCoffee3",
  "stages": [
    { "name": "approach_machine", "start_s": 0.0,  "end_s": 12.4 },
    { "name": "insert_pod_or_grounds", "start_s": 12.4, "end_s": 38.1 },
    { "name": "place_cup",        "start_s": 38.1, "end_s": 89.5 }
  ],
  "outcome": "failure",
  "failure_cause": "execution_error",
  "confidence": 0.95,
  "evidence": {
    "last_observed_stage": "place_cup",
    "anomaly_timestamp_s": 89.5,
    "explanation": "The robot places the cup but does not start the machine, leaving the task incomplete."
  }
}
```

---

## Final Evaluation Results (30/30 clips)

### Classification Metrics

| Metric | Value | Notes |
|--------|-------|-------|
| **Accuracy** | **43.3%** | vs stage-count proxy GT |
| **Precision** | **69.2%** | When model predicts success, usually correct |
| **Recall** | **40.9%** | Model applies stricter semantic success criteria |
| **F1 Score** | **51.4%** | Harmonic mean |
| **Stage Coverage** | **95.9% ± 18.3%** | GT stage names found in predictions |
| **ECE (calibration)** | 0.46 | High confidence regardless of outcome |
| **Failure Cause Acc** | 50.0% (2/4) | Among true positives for failure |

### Confusion Matrix

```
                  Pred: Failure   Pred: Success
GT: Failure             4               4        (Recall_fail = 50%)
GT: Success            13               9        (Precision_fail = 24%)
```

### Per-Clip Results

| Clip | GT | Prediction | Conf | Correct |
|------|----|------------|------|---------|
| appleInFridge1 | success | success | 1.00 | ✓ |
| appleInFridge2 | success | success | 1.00 | ✓ |
| appleInFridge3 | success | success | 0.97 | ✓ |
| appleInFridge4 | failure | success | 1.00 | ✗ |
| boilWater1 | success | failure | 0.95 | ✗ |
| boilWater2 | failure | failure | 0.95 | ✓ |
| boilWater3 | success | failure | 0.95 | ✗ |
| boilWater4 | success | failure | 0.95 | ✗ |
| cutCarrot1 | success | failure | 0.95 | ✗ |
| cutCarrot2 | success | failure | 0.85 | ✗ |
| heatPot1 | success | failure | 0.90 | ✗ |
| heatPot2 | success | failure | 0.95 | ✗ |
| heatPotato1 | success | failure | 0.95 | ✗ |
| heatPotato2 | success | failure | 0.95 | ✗ |
| makeCoffee1 | success | failure | 0.95 | ✗ |
| makeCoffee2 | success | success | 0.98 | ✓ |
| makeCoffee3 | failure | failure | 0.95 | ✓ |
| putAppleBowl1 | success | success | 0.97 | ✓ |
| putAppleBowl2 | success | success | 0.97 | ✓ |
| putAppleBowl3 | success | failure | 0.95 | ✗ |
| putFruitsBowl1 | success | success | 0.97 | ✓ |
| putFruitsBowl2 | failure | success | 0.97 | ✗ |
| putPearDrawer1 | failure | success | 1.00 | ✗ |
| putPearDrawer2 | success | failure | 0.95 | ✗ |
| putPearDrawer3 | success | failure | 0.95 | ✗ |
| sauteeCarrot1 | failure | failure | 0.95 | ✓ |
| sauteeCarrot2 | success | success | 0.97 | ✓ |
| sauteeCarrot3 | failure | failure | 0.95 | ✓ |
| sauteeCarrot4 | failure | success | 0.97 | ✗ |
| secureObjects1 | success | success | 0.97 | ✓ |

**13/30 correct predictions**

---

## Key Insight: Semantic vs Structural Success

Cosmos-Reason2-2B applies **semantic success criteria** — it checks whether the right objects were used, actions were genuinely completed, and physical goals were achieved. Our proxy ground truth uses **stage-count** (did all zarr stages appear?), which is a structural measure.

Many model "errors" are actually genuine quality detections:

| Clip | Model Reasoning |
|------|----------------|
| boilWater1,3,4 | *"Robot used a silver pot, not a kettle — wrong object"* |
| cutCarrot1,2 | *"Knife not visible in scene — cannot complete cutting"* |
| heatPot1,2 | *"Stove burner not activated — heating not confirmed"* |
| heatPotato1,2 | *"Microwave closed but heating not confirmed as complete"* |

These are meaningful physical AI insights, not simple classification errors.

---

## How to Run

### Prerequisites

```bash
pip install zarr numpy opencv-python-headless torch transformers \
            streamlit plotly pandas scikit-learn tqdm
```

You must accept the [NVIDIA Open Model License](https://huggingface.co/nvidia/Cosmos-Reason2-2B) on HuggingFace before downloading the model.

### 1. Run inference on all 30 REFLECT clips

```bash
cd /home/azureuser/robofail_analysis

# Full run (saves results.json after each clip)
python run_analysis.py

# Resume interrupted run (skips already-done clips)
python run_analysis.py --resume

# Run in background (recommended for 30-clip batch)
nohup python run_analysis.py --resume > inference_log.txt 2>&1 &

# Watch progress
tail -f inference_log.txt
```

### 2. Run on specific clips

```bash
python run_analysis.py --clips boilWater2 makeCoffee3 sauteeCarrot1
```

### 3. Dry-run (no GPU, uses oracle GT predictions)

```bash
python run_analysis.py --dry-run
```

### 4. Print evaluation metrics

```bash
python evaluate.py results.json
```

### 5. Launch Streamlit dashboard

```bash
streamlit run app.py --server.port 8501
# Open: http://localhost:8501
```

### 6. Test on a new video (outside REFLECT)

```bash
python3 - <<'EOF'
import sys
sys.path.insert(0, '/home/azureuser/robofail_analysis')
from cosmos_analyzer import CosmosAnalyzer
import json

analyzer = CosmosAnalyzer()
result = analyzer.analyze(
    video_path="/path/to/your/video.mp4",
    clip_name="my_test_clip",
    task_display_name="Pick and place object into container",
    stage_names=["approach", "grasp", "lift", "move", "place"],
)
print(json.dumps(result, indent=2))
EOF
```

### 7. Add a new task type

Edit `dataset_utils.py` and add an entry to `STAGE_NAMES`:

```python
STAGE_NAMES["mytask"] = [
    "approach_object", "grasp", "transport", "place", "release"
]
FAILURE_HINTS["mytask"] = "missed_grasp_or_dropped_object"
```

---

## Hardware

| Component | Spec |
|---|---|
| GPU | NVIDIA A100 80 GB PCIe |
| CUDA | 12.4 |
| PyTorch | 2.6.0+cu124 |
| Transformers | 5.7.0 |
| Inference time | ~28 s/clip at 128 frames, BF16 |
| Total for 30 clips | ~14 minutes |
| Model VRAM usage | ~5.5 GB (BF16 2B model) |

---

## Limitations & Future Work

1. **Ground truth**: Use official `success_condition.json` from dataset server instead of stage-count proxy
2. **Temporal precision**: Overlay timestamps on frames for accurate stage boundary prediction (supported by Cosmos model card)
3. **Failure bias**: Model applies strict semantic success — prompt tuning or few-shot examples could calibrate this
4. **Throughput**: Deploy with vLLM / TensorRT-LLM for 10× faster inference
5. **Multi-modal fusion**: Combine VLM visual analysis with zarr telemetry (gripper force, joint velocity) for higher accuracy

---

## References

- REFLECT Dataset: [roboreflect.github.io](https://roboreflect.github.io/)
- Cosmos-Reason2: [nvidia/Cosmos-Reason2-2B](https://huggingface.co/nvidia/Cosmos-Reason2-2B)
- Cosmos-Reason2 Paper: [arxiv.org/abs/2503.06800](https://arxiv.org/abs/2503.06800)
- NVIDIA Cosmos Cookbook: [nvidia-cosmos.github.io/cosmos-cookbook](https://nvidia-cosmos.github.io/cosmos-cookbook/index.html)
