"""
Main pipeline: run Cosmos-Reason2-2B on all 30 REFLECT clips,
save per-clip results + aggregated evaluation metrics to results.json.
Supports --resume to skip already-processed clips.
"""

import os
import json
import time
import argparse
import traceback
from typing import List, Dict

from dataset_utils import load_all_clips, ClipMeta
from cosmos_analyzer import CosmosAnalyzer
from evaluate import full_evaluation, print_summary

RESULTS_FILE = os.path.join(os.path.dirname(__file__), "results.json")

TASK_DISPLAY = {
    "appleinfridge": "Place an apple in the refrigerator",
    "boilwater": "Boil water using a kettle on the stove",
    "cutcarrot": "Cut a carrot with a knife",
    "heatpot": "Heat a pot on the stove",
    "heatpotato": "Heat a potato in the microwave",
    "makecoffee": "Make coffee with a coffee machine",
    "putapplebowl": "Put an apple into a bowl",
    "putfruitsbowl": "Put multiple fruits into a bowl",
    "putpeardrawer": "Put a pear into a drawer",
    "sauteecarrot": "Sauté carrots in a pan",
    "secureobjects": "Secure objects on a surface",
}


def build_result_record(clip: ClipMeta, cosmos_out: Dict, elapsed: float) -> Dict:
    return {
        "clip_name": clip.clip_name,
        "task": clip.task,
        "video_path": clip.video_path,
        "duration_s": round(clip.duration_s, 1),
        # Ground truth
        "gt_outcome": clip.gt_outcome,
        "gt_failure_cause": clip.gt_failure_cause,
        "gt_stages": clip.gt_stages,
        "gt_n_stages": clip.n_unique_stages,
        # Predictions
        "pred_outcome": cosmos_out.get("outcome", "unknown"),
        "pred_failure_cause": cosmos_out.get("failure_cause"),
        "pred_stages": cosmos_out.get("stages", []),
        "pred_confidence": cosmos_out.get("confidence", 0.5),
        "pred_evidence": cosmos_out.get("evidence", {}),
        # Meta
        "inference_time_s": round(elapsed, 1),
        "correct": clip.gt_outcome == cosmos_out.get("outcome", ""),
        "raw_response_snippet": cosmos_out.get("raw_response", "")[:500],
    }


def load_existing_results() -> Dict[str, Dict]:
    """Load already-computed results keyed by clip_name."""
    if not os.path.exists(RESULTS_FILE):
        return {}
    with open(RESULTS_FILE) as f:
        data = json.load(f)
    return {r["clip_name"]: r for r in data.get("results", [])}


def save_results(records: List[Dict], eval_metrics: Dict):
    payload = {"results": records, "evaluation": eval_metrics}
    with open(RESULTS_FILE, "w") as f:
        json.dump(payload, f, indent=2)
    print(f"\nResults saved to {RESULTS_FILE}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--resume", action="store_true",
                        help="Skip clips already present in results.json")
    parser.add_argument("--clips", nargs="*",
                        help="Process only these clip names (default: all 30)")
    parser.add_argument("--fps", type=float, default=4.0,
                        help="Video FPS for Cosmos input (default: 4)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Skip model inference; use placeholder predictions")
    args = parser.parse_args()

    clips = load_all_clips()
    if args.clips:
        clips = [c for c in clips if c.clip_name in args.clips]

    print(f"\n{'='*60}")
    print(f"  REFLECT Dataset Analysis with Cosmos-Reason2-2B")
    print(f"  Clips to process: {len(clips)}")
    succ = sum(1 for c in clips if c.gt_outcome == "success")
    print(f"  GT distribution : {succ} success / {len(clips)-succ} failure")
    print(f"{'='*60}\n")

    existing = load_existing_results() if args.resume else {}
    analyzer = CosmosAnalyzer() if not args.dry_run else None

    records: List[Dict] = list(existing.values())
    processed_names = set(existing.keys())

    for i, clip in enumerate(clips):
        if clip.clip_name in processed_names:
            print(f"[{i+1:2d}/{len(clips)}] {clip.clip_name:25s}  (skipped – already processed)")
            continue

        print(f"\n[{i+1:2d}/{len(clips)}] {clip.clip_name:25s}  "
              f"GT={clip.gt_outcome:8s}  dur={clip.duration_s:.0f}s  "
              f"stages={clip.n_unique_stages}/{len(clip.stage_names)}")

        t0 = time.time()
        try:
            if args.dry_run:
                cosmos_out = {
                    "video_id": clip.clip_name,
                    "stages": [{"name": s, "start_s": 0.0, "end_s": 1.0} for s in clip.stage_names[:3]],
                    "outcome": clip.gt_outcome,  # oracle for dry-run
                    "failure_cause": clip.gt_failure_cause,
                    "confidence": 0.85,
                    "evidence": {"explanation": "dry-run oracle"},
                    "raw_response": "dry-run",
                }
            else:
                cosmos_out = analyzer.analyze(
                    video_path=clip.video_path,
                    clip_name=clip.clip_name,
                    task_display_name=TASK_DISPLAY.get(clip.task, clip.task),
                    stage_names=clip.stage_names,
                    fps=args.fps,
                )
        except Exception as e:
            print(f"  ERROR: {e}")
            traceback.print_exc()
            cosmos_out = {
                "video_id": clip.clip_name,
                "stages": [],
                "outcome": "unknown",
                "failure_cause": None,
                "confidence": 0.0,
                "evidence": {"explanation": f"inference error: {e}"},
                "raw_response": "",
            }

        elapsed = time.time() - t0
        record = build_result_record(clip, cosmos_out, elapsed)
        records.append(record)
        processed_names.add(clip.clip_name)

        pred = record["pred_outcome"]
        gt = record["gt_outcome"]
        mark = "✓" if record["correct"] else "✗"
        print(f"  {mark} pred={pred:8s}  conf={record['pred_confidence']:.2f}  "
              f"time={elapsed:.0f}s")

        # Save incrementally after each clip
        valid_records = [r for r in records if r["clip_name"] in processed_names]
        eval_metrics = full_evaluation(valid_records)
        save_results(valid_records, eval_metrics)

    print("\n" + "="*60)
    print("  FINAL RESULTS")
    print("="*60)
    valid_records = [r for r in records if r["clip_name"] in processed_names]
    final_eval = full_evaluation(valid_records)
    print_summary(final_eval)
    save_results(valid_records, final_eval)


if __name__ == "__main__":
    main()
