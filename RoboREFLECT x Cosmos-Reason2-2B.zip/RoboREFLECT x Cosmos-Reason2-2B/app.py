"""
Streamlit dashboard: REFLECT × Cosmos-Reason2-2B evaluation overview.
Run: streamlit run app.py
Reads results.json produced by run_analysis.py.
"""

import os
import json
import math
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

RESULTS_FILE = os.path.join(os.path.dirname(__file__), "results.json")

st.set_page_config(
    page_title="REFLECT × Cosmos-Reason2-2B",
    page_icon="🤖",
    layout="wide",
)


# ── Data loader ──────────────────────────────────────────────────────────────

@st.cache_data(ttl=30)
def load_results():
    if not os.path.exists(RESULTS_FILE):
        return None, None
    with open(RESULTS_FILE) as f:
        data = json.load(f)
    df = pd.DataFrame(data.get("results", []))
    ev = data.get("evaluation", {})
    return df, ev


# ── Colour helpers ────────────────────────────────────────────────────────────

def outcome_colour(outcome):
    return {"success": "#2ECC71", "failure": "#E74C3C"}.get(outcome, "#95A5A6")


# ── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    st.title("🤖 REFLECT Analysis")
    st.markdown("**Model:** nvidia/Cosmos-Reason2-2B")
    st.markdown("**Dataset:** REFLECT (30 robot manipulation clips)")
    if st.button("🔄 Refresh results"):
        st.cache_data.clear()
    st.divider()
    st.markdown("### Filters")
    outcome_filter = st.multiselect(
        "GT Outcome", ["success", "failure"], default=["success", "failure"]
    )
    task_filter_all = st.checkbox("All tasks", value=True)


# ── Main ──────────────────────────────────────────────────────────────────────

st.title("Robot Task Monitoring: REFLECT × Cosmos-Reason2-2B")
st.markdown(
    "Evaluating **nvidia/Cosmos-Reason2-2B** (physical AI reasoning VLM) on the "
    "[REFLECT dataset](https://roboreflect.github.io/) — 30 real robot manipulation clips "
    "annotated with task stages, success/failure outcomes, and failure causes."
)

df, ev = load_results()

if df is None or df.empty:
    st.warning(
        "No results found. Run the analysis first:\n\n"
        "```bash\ncd /home/azureuser/robofail_analysis\n"
        "python run_analysis.py\n```"
    )
    st.stop()

# Apply filters
df = df[df["gt_outcome"].isin(outcome_filter)]
if not task_filter_all:
    tasks = st.sidebar.multiselect("Tasks", sorted(df["task"].unique()), default=sorted(df["task"].unique()))
    df = df[df["task"].isin(tasks)]

# ── KPI row ───────────────────────────────────────────────────────────────────

oc = ev.get("outcome_classification", {})
sc = ev.get("stage_coverage", {})
cc = ev.get("confidence_calibration", {})

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Accuracy", f"{oc.get('accuracy', 0):.1%}")
c2.metric("Precision", f"{oc.get('precision', 0):.1%}")
c3.metric("Recall", f"{oc.get('recall', 0):.1%}")
c4.metric("F1 Score", f"{oc.get('f1_score', 0):.1%}")
c5.metric("Stage Coverage", f"{sc.get('mean_stage_coverage', 0):.1%}")

st.divider()

# ── Row 1: Confusion Matrix + Outcome Distribution ───────────────────────────

col_left, col_right = st.columns(2)

with col_left:
    st.subheader("Confusion Matrix")
    cm_data = oc.get("confusion_matrix", {})
    if cm_data:
        mat = cm_data["matrix"]
        labels = cm_data["labels"]
        fig_cm = go.Figure(go.Heatmap(
            z=mat,
            x=[f"Pred: {l}" for l in labels],
            y=[f"GT: {l}" for l in labels],
            colorscale="Blues",
            text=mat,
            texttemplate="%{text}",
            showscale=True,
        ))
        fig_cm.update_layout(height=350, margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig_cm, use_container_width=True)
        tp = cm_data.get("TP", 0)
        tn = cm_data.get("TN", 0)
        fp = cm_data.get("FP", 0)
        fn = cm_data.get("FN", 0)
        st.caption(f"TP={tp}  TN={tn}  FP={fp}  FN={fn}")

with col_right:
    st.subheader("GT vs Predicted Outcome Distribution")
    gt_counts = df["gt_outcome"].value_counts()
    pred_counts = df["pred_outcome"].value_counts()
    categories = ["success", "failure", "unknown"]
    fig_bar = go.Figure(data=[
        go.Bar(name="Ground Truth", x=categories,
               y=[gt_counts.get(c, 0) for c in categories],
               marker_color=["#2ECC71", "#E74C3C", "#95A5A6"]),
        go.Bar(name="Predicted", x=categories,
               y=[pred_counts.get(c, 0) for c in categories],
               marker_color=["#27AE60", "#C0392B", "#7F8C8D"]),
    ])
    fig_bar.update_layout(
        barmode="group", height=350,
        margin=dict(l=10, r=10, t=10, b=10),
        yaxis_title="Count",
    )
    st.plotly_chart(fig_bar, use_container_width=True)

# ── Row 2: Per-task accuracy + confidence distribution ────────────────────────

col_a, col_b = st.columns(2)

with col_a:
    st.subheader("Per-Task Accuracy")
    task_acc = (
        df.groupby("task")
        .apply(lambda g: (g["gt_outcome"] == g["pred_outcome"]).mean())
        .reset_index()
        .rename(columns={0: "accuracy"})
        .sort_values("accuracy", ascending=True)
    )
    fig_task = px.bar(
        task_acc, x="accuracy", y="task", orientation="h",
        color="accuracy", color_continuous_scale="RdYlGn",
        range_color=[0, 1], labels={"accuracy": "Accuracy", "task": "Task"},
    )
    fig_task.update_layout(height=400, margin=dict(l=10, r=10, t=10, b=10))
    st.plotly_chart(fig_task, use_container_width=True)

with col_b:
    st.subheader("Confidence Score Distribution")
    conf_df = df.copy()
    conf_df["correct_label"] = conf_df["correct"].map({True: "Correct", False: "Incorrect"})
    fig_conf = px.histogram(
        conf_df, x="pred_confidence", color="correct_label",
        barmode="overlay", nbins=20,
        color_discrete_map={"Correct": "#2ECC71", "Incorrect": "#E74C3C"},
        labels={"pred_confidence": "Predicted Confidence"},
    )
    fig_conf.update_layout(height=400, margin=dict(l=10, r=10, t=10, b=10))
    st.plotly_chart(fig_conf, use_container_width=True)

# ── Row 3: Failure cause analysis ─────────────────────────────────────────────

st.subheader("Failure Cause Analysis")
fail_df = df[df["gt_outcome"] == "failure"].copy()

if not fail_df.empty:
    col_c, col_d = st.columns(2)
    with col_c:
        gt_causes = fail_df["gt_failure_cause"].fillna("unknown").value_counts()
        fig_gt_cause = px.pie(
            values=gt_causes.values, names=gt_causes.index,
            title="GT Failure Causes",
            color_discrete_sequence=px.colors.qualitative.Set2,
        )
        fig_gt_cause.update_layout(height=350, margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig_gt_cause, use_container_width=True)
    with col_d:
        pred_causes = fail_df["pred_failure_cause"].fillna("not_detected").value_counts()
        fig_pred_cause = px.pie(
            values=pred_causes.values, names=pred_causes.index,
            title="Predicted Failure Causes (true failures only)",
            color_discrete_sequence=px.colors.qualitative.Set3,
        )
        fig_pred_cause.update_layout(height=350, margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig_pred_cause, use_container_width=True)
else:
    st.info("No failure samples in filtered view.")

# ── Row 4: Stage coverage heatmap ─────────────────────────────────────────────

st.subheader("Stage Coverage by Clip (GT stages found in prediction)")

coverage_data = []
for _, row in df.iterrows():
    gt_s = set(s["name"] for s in (row.get("gt_stages") or []))
    pred_s = set(s["name"] for s in (row.get("pred_stages") or []))
    cov = len(gt_s & pred_s) / max(len(gt_s), 1)
    coverage_data.append({
        "clip": row["clip_name"],
        "task": row["task"],
        "coverage": round(cov, 2),
        "gt_outcome": row["gt_outcome"],
        "pred_outcome": row["pred_outcome"],
    })
cov_df = pd.DataFrame(coverage_data).sort_values(["task", "clip"])

fig_cov = px.bar(
    cov_df, x="clip", y="coverage", color="gt_outcome",
    color_discrete_map={"success": "#2ECC71", "failure": "#E74C3C"},
    labels={"coverage": "Stage Coverage", "clip": "Clip"},
    title="",
)
fig_cov.update_xaxes(tickangle=45)
fig_cov.add_hline(y=cov_df["coverage"].mean(), line_dash="dash",
                  annotation_text=f"Mean={cov_df['coverage'].mean():.2f}")
fig_cov.update_layout(height=380, margin=dict(l=10, r=10, t=10, b=80))
st.plotly_chart(fig_cov, use_container_width=True)

# ── Row 5: Per-clip detail table ──────────────────────────────────────────────

st.subheader("Per-Clip Results")

display_df = df[[
    "clip_name", "task", "duration_s",
    "gt_outcome", "pred_outcome", "pred_confidence",
    "gt_failure_cause", "pred_failure_cause",
    "correct", "inference_time_s",
]].copy()
display_df["correct"] = display_df["correct"].map({True: "✓", False: "✗"})
display_df.columns = [
    "Clip", "Task", "Duration(s)",
    "GT Outcome", "Pred Outcome", "Confidence",
    "GT Cause", "Pred Cause",
    "Correct", "Infer Time(s)",
]

def colour_row(row):
    colour = "#d4edda" if row["Correct"] == "✓" else "#f8d7da"
    return [f"background-color: {colour}"] * len(row)

st.dataframe(
    display_df.style.apply(colour_row, axis=1),
    use_container_width=True,
    height=600,
)

# ── Row 6: Calibration plot ────────────────────────────────────────────────────

st.subheader("Reliability / Calibration Plot")

calibration_df = df[
    df["gt_outcome"].isin(["success", "failure"]) &
    df["pred_outcome"].isin(["success", "failure"])
].copy()
calibration_df["correct_int"] = (calibration_df["gt_outcome"] == calibration_df["pred_outcome"]).astype(int)
calibration_df["conf_bin"] = pd.cut(calibration_df["pred_confidence"], bins=10, labels=False)

if not calibration_df.empty:
    cal_grp = calibration_df.groupby("conf_bin").agg(
        mean_conf=("pred_confidence", "mean"),
        mean_acc=("correct_int", "mean"),
        count=("correct_int", "count"),
    ).reset_index()

    fig_cal = go.Figure()
    fig_cal.add_trace(go.Scatter(
        x=[0, 1], y=[0, 1], mode="lines", name="Perfect Calibration",
        line=dict(dash="dash", color="gray"),
    ))
    fig_cal.add_trace(go.Scatter(
        x=cal_grp["mean_conf"], y=cal_grp["mean_acc"],
        mode="markers+lines", name="Model",
        marker=dict(size=cal_grp["count"] * 3, color="#3498DB"),
    ))
    fig_cal.update_layout(
        xaxis_title="Mean Confidence", yaxis_title="Fraction Correct",
        height=380, margin=dict(l=10, r=10, t=10, b=10),
    )
    st.plotly_chart(fig_cal, use_container_width=True)
    ece = ev.get("confidence_calibration", {}).get("ece", "N/A")
    st.caption(f"Expected Calibration Error (ECE) = {ece}")

# ── Footer ────────────────────────────────────────────────────────────────────

st.divider()
n_done = len(df)
n_correct = df["correct"].eq("✓").sum() if "✓" in df["correct"].values else df["correct"].sum()
st.markdown(
    f"**{n_done}/30** clips analysed  |  "
    f"**{n_correct}** correct predictions  |  "
    f"Model: `nvidia/Cosmos-Reason2-2B`  |  "
    f"Dataset: REFLECT"
)
