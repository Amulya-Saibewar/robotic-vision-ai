"""
Cosmos-Reason2-2B inference wrapper for robot task video analysis.
Model: nvidia/Cosmos-Reason2-2B (Qwen3-VL based, physical AI reasoning VLM)
Input: video file path + structured task prompt
Output: JSON with stages, outcome, failure_cause, confidence, evidence

Pre-sampling strategy: we extract MAX_FRAMES frames uniformly at TARGET_FPS
and write a compact temp MP4. This avoids the full-video CPU decode that the
Qwen3VL processor would perform on long clips (>1 min = thousands of frames).
"""

import os
import json
import re
import time
import tempfile
import shutil
import cv2
import numpy as np
import torch
import transformers
from typing import Optional

HF_TOKEN = "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"
MODEL_ID = "nvidia/Cosmos-Reason2-2B"
TARGET_FPS = 4.0   # recommended by model card
MAX_FRAMES = 128   # cap to keep VRAM and decode time bounded

SYSTEM_PROMPT = (
    "You are an expert robotics video analyst. Analyze robot manipulation videos "
    "and produce structured JSON describing task stages, outcomes, and failure causes. "
    "Answer the question in the following format: "
    "<think>\nyour reasoning\n</think>\n\n<answer>\nyour answer\n</answer>."
)

ANALYSIS_TEMPLATE = """Analyze this robot manipulation video carefully.

Task: {task_display_name}
Known task stages (in expected order): {stage_list}

Answer the following questions and return ONLY valid JSON (no markdown code fences):
{{
  "video_id": "{clip_name}",
  "stages": [
    {{"name": "<stage_name>", "start_s": <float>, "end_s": <float>}}
  ],
  "outcome": "<success or failure>",
  "failure_cause": "<one of: missed_grasp | dropped_object | incorrect_placement | collision | timeout | joint_limit | execution_error | null>",
  "confidence": <0.0 to 1.0>,
  "evidence": {{
    "last_observed_stage": "<stage_name>",
    "anomaly_timestamp_s": <float or null>,
    "explanation": "<1-2 sentences describing what you observed>"
  }}
}}

Rules:
- List only stages you actually observe in the video.
- Set outcome to "failure" if the robot does NOT complete all expected stages.
- Set failure_cause to null if outcome is "success".
- Estimate timestamps in seconds from video start.
- confidence reflects your certainty (0=unsure, 1=certain).
"""


def _make_sampled_clip(src_path: str, out_path: str,
                        target_fps: float = TARGET_FPS,
                        max_frames: int = MAX_FRAMES) -> float:
    """
    Decode src_path with OpenCV (fast, seeks directly to each frame),
    uniformly subsample to at most max_frames at target_fps, write a compact
    temp MP4, and return the effective FPS written (always target_fps).
    """
    cap = cv2.VideoCapture(src_path)
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))

    step = max(1, int(src_fps / target_fps))
    indices = list(range(0, total, step))
    if len(indices) > max_frames:
        indices = [indices[int(i * (len(indices) - 1) / (max_frames - 1))]
                   for i in range(max_frames)]

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(out_path, fourcc, target_fps, (w, h))
    for idx in indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = cap.read()
        if ret:
            writer.write(frame)
    cap.release()
    writer.release()
    return target_fps


class CosmosAnalyzer:
    def __init__(self):
        self.model = None
        self.processor = None
        self._loaded = False
        self._tmp_dir = tempfile.mkdtemp(prefix="cosmos_clips_")

    def __del__(self):
        shutil.rmtree(self._tmp_dir, ignore_errors=True)

    def load(self):
        if self._loaded:
            return
        print(f"Loading {MODEL_ID} ...")
        t0 = time.time()
        self.model = transformers.Qwen3VLForConditionalGeneration.from_pretrained(
            MODEL_ID,
            torch_dtype=torch.bfloat16,
            device_map="auto",
            attn_implementation="sdpa",
            token=HF_TOKEN,
        )
        self.processor = transformers.AutoProcessor.from_pretrained(
            MODEL_ID, token=HF_TOKEN
        )
        self.model.eval()
        self._loaded = True
        print(f"Model loaded in {time.time()-t0:.1f}s  "
              f"(device={next(self.model.parameters()).device})")

    @torch.inference_mode()
    def analyze(
        self,
        video_path: str,
        clip_name: str,
        task_display_name: str,
        stage_names: list,
        fps: float = TARGET_FPS,
    ) -> dict:
        """Run Cosmos inference on a single video. Returns parsed result dict."""
        self.load()

        # Pre-sample to a compact temp clip so the processor doesn't decode
        # the full multi-minute video in CPU memory.
        tmp_clip = os.path.join(self._tmp_dir, f"{clip_name}.mp4")
        eff_fps = _make_sampled_clip(video_path, tmp_clip, target_fps=fps,
                                     max_frames=MAX_FRAMES)

        stage_list = " → ".join(stage_names)
        user_text = ANALYSIS_TEMPLATE.format(
            task_display_name=task_display_name,
            stage_list=stage_list,
            clip_name=clip_name,
        )

        messages = [
            {
                "role": "system",
                "content": [{"type": "text", "text": SYSTEM_PROMPT}],
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "video",
                        "video": tmp_clip,
                        "fps": eff_fps,
                    },
                    {"type": "text", "text": user_text},
                ],
            },
        ]

        inputs = self.processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
            fps=eff_fps,
        )
        inputs = {k: v.to(self.model.device) if hasattr(v, "to") else v
                  for k, v in inputs.items()}

        generated_ids = self.model.generate(
            **inputs,
            max_new_tokens=4096,
            do_sample=False,
            temperature=None,
            top_p=None,
        )
        trimmed = [
            out[len(inp):]
            for inp, out in zip(inputs["input_ids"], generated_ids)
        ]
        raw_text = self.processor.batch_decode(
            trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )[0]

        # Clean up temp file to save disk
        try:
            os.remove(tmp_clip)
        except OSError:
            pass

        return self._parse_response(raw_text, clip_name, stage_names)

    # ------------------------------------------------------------------
    def _parse_response(self, raw: str, clip_name: str, stage_names: list) -> dict:
        """Extract <answer> block and parse JSON from model output."""
        # Strip <think>...</think> block
        think_removed = re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()

        # Try to extract <answer>...</answer>
        answer_match = re.search(r"<answer>(.*?)</answer>", think_removed, re.DOTALL)
        json_str = answer_match.group(1).strip() if answer_match else think_removed

        # Remove markdown code fences if present
        json_str = re.sub(r"```(?:json)?", "", json_str).strip().rstrip("`").strip()

        # Try to locate first { ... } block
        brace_match = re.search(r"\{.*\}", json_str, re.DOTALL)
        if brace_match:
            json_str = brace_match.group(0)

        try:
            result = json.loads(json_str)
        except json.JSONDecodeError:
            result = self._fallback_result(clip_name, stage_names, raw)

        result["raw_response"] = raw[:2000]  # store truncated raw for debugging
        result.setdefault("video_id", clip_name)
        result.setdefault("stages", [])
        result.setdefault("outcome", "unknown")
        result.setdefault("failure_cause", None)
        result.setdefault("confidence", 0.5)
        result.setdefault("evidence", {"explanation": "parse error"})

        # Normalise outcome string
        outcome_raw = str(result.get("outcome", "")).lower()
        if "success" in outcome_raw:
            result["outcome"] = "success"
        elif "fail" in outcome_raw:
            result["outcome"] = "failure"
        else:
            result["outcome"] = "unknown"

        if result["outcome"] == "success":
            result["failure_cause"] = None

        return result

    @staticmethod
    def _fallback_result(clip_name: str, stage_names: list, raw: str) -> dict:
        """Heuristic fallback when JSON parsing fails."""
        raw_lower = raw.lower()
        outcome = "failure" if "fail" in raw_lower else "success"
        cause = None
        for keyword in ["dropped", "missed", "collision", "timeout", "incorrect"]:
            if keyword in raw_lower:
                cause_map = {
                    "dropped": "dropped_object",
                    "missed": "missed_grasp",
                    "collision": "collision",
                    "timeout": "timeout",
                    "incorrect": "incorrect_placement",
                }
                cause = cause_map[keyword]
                break
        return {
            "video_id": clip_name,
            "stages": [{"name": s, "start_s": 0.0, "end_s": 0.0} for s in stage_names[:3]],
            "outcome": outcome,
            "failure_cause": cause if outcome == "failure" else None,
            "confidence": 0.4,
            "evidence": {"explanation": "JSON parse failed; heuristic extraction used."},
        }
