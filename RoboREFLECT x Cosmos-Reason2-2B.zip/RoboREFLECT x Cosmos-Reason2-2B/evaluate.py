"""
Evaluation metrics for robot task video analysis.
Compares Cosmos-predicted outcomes vs ground-truth zarr-derived labels.
Metrics: accuracy, precision, recall, F1, confusion matrix, stage coverage rate.
"""

import json
import numpy as np
from typing import List, Dict, Optional, Tuple
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report,
)


def outcome_to_int(outcome: str) -> int:
    mapping = {"success": 1, "failure": 0, "unknown": -1}
    return mapping.get(outcome.lower(), -1)


def compute_outcome_metrics(results: List[Dict]) -> Dict:
    """
    Compute binary classification metrics for success/failure prediction.
    Skips samples where gt or pred is 'unknown'.
    """
    valid = [(r["gt_outcome"], r["pred_outcome"])
             for r in results
             if r["gt_outcome"] in ("success", "failure")
             and r["pred_outcome"] in ("success", "failure")]

    if not valid:
        return {"error": "No valid predictions to evaluate"}

    y_true = [outcome_to_int(g) for g, _ in valid]
    y_pred = [outcome_to_int(p) for _, p in valid]

    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1]).tolist()
    report = classification_report(
        y_true, y_pred, labels=[0, 1], target_names=["failure", "success"],
        output_dict=True, zero_division=0
    )

    n_correct = sum(1 for t, p in zip(y_true, y_pred) if t == p)
    n_total = len(y_true)
    n_skip = len(results) - len(valid)

    return {
        "n_total": n_total,
        "n_skipped_unknown": n_skip,
        "n_correct": n_correct,
        "accuracy": round(acc, 4),
        "precision": round(prec, 4),
        "recall": round(rec, 4),
        "f1_score": round(f1, 4),
        "confusion_matrix": {
            "labels": ["failure", "success"],
            "matrix": cm,
            "TP": cm[1][1],
            "TN": cm[0][0],
            "FP": cm[0][1],
            "FN": cm[1][0],
        },
        "per_class_report": report,
    }


def compute_stage_coverage(results: List[Dict]) -> Dict:
    """
    Stage coverage: fraction of GT stage names that appear in predicted stages.
    Averaged across all clips.
    """
    coverages = []
    for r in results:
        gt_stages = set(s["name"] for s in r.get("gt_stages", []))
        pred_stages = set(s["name"] for s in r.get("pred_stages", []))
        if not gt_stages:
            continue
        overlap = gt_stages & pred_stages
        coverages.append(len(overlap) / len(gt_stages))

    if not coverages:
        return {"mean_stage_coverage": 0.0}
    return {
        "mean_stage_coverage": round(float(np.mean(coverages)), 4),
        "std_stage_coverage": round(float(np.std(coverages)), 4),
        "min_stage_coverage": round(float(np.min(coverages)), 4),
        "max_stage_coverage": round(float(np.max(coverages)), 4),
    }


def compute_confidence_calibration(results: List[Dict]) -> Dict:
    """
    Expected Calibration Error (ECE) — how well confidence scores reflect accuracy.
    Also returns mean confidence split by correct/incorrect predictions.
    """
    valid = [
        (r["pred_confidence"], int(r["gt_outcome"] == r["pred_outcome"]))
        for r in results
        if r["gt_outcome"] in ("success", "failure")
        and r["pred_outcome"] in ("success", "failure")
        and r.get("pred_confidence") is not None
    ]
    if not valid:
        return {}

    confs = np.array([v[0] for v in valid], dtype=float)
    correct = np.array([v[1] for v in valid], dtype=float)

    bins = np.linspace(0, 1, 11)
    ece = 0.0
    for i in range(len(bins) - 1):
        mask = (confs >= bins[i]) & (confs < bins[i + 1])
        if mask.sum() == 0:
            continue
        bin_conf = confs[mask].mean()
        bin_acc = correct[mask].mean()
        ece += mask.sum() * abs(bin_conf - bin_acc) / len(confs)

    correct_confs = confs[correct == 1]
    wrong_confs = confs[correct == 0]
    return {
        "ece": round(float(ece), 4),
        "mean_confidence_correct": round(float(correct_confs.mean()) if len(correct_confs) else 0, 4),
        "mean_confidence_incorrect": round(float(wrong_confs.mean()) if len(wrong_confs) else 0, 4),
        "mean_confidence_overall": round(float(confs.mean()), 4),
    }


def compute_failure_cause_accuracy(results: List[Dict]) -> Dict:
    """
    Among predicted failures, fraction where predicted failure_cause
    matches the ground-truth failure_cause (exact string match).
    """
    pred_fail = [
        r for r in results
        if r["pred_outcome"] == "failure" and r["gt_outcome"] == "failure"
    ]
    if not pred_fail:
        return {"failure_cause_accuracy": 0.0, "n_failure_samples": 0}

    hits = sum(
        1 for r in pred_fail
        if r.get("pred_failure_cause") and r.get("gt_failure_cause")
        and r["pred_failure_cause"].split("_")[0] in (r.get("gt_failure_cause") or "")
    )
    return {
        "failure_cause_accuracy": round(hits / len(pred_fail), 4),
        "n_failure_samples": len(pred_fail),
        "n_cause_matched": hits,
    }


def full_evaluation(results: List[Dict]) -> Dict:
    return {
        "outcome_classification": compute_outcome_metrics(results),
        "stage_coverage": compute_stage_coverage(results),
        "confidence_calibration": compute_confidence_calibration(results),
        "failure_cause": compute_failure_cause_accuracy(results),
    }


def print_summary(eval_dict: Dict):
    oc = eval_dict["outcome_classification"]
    sc = eval_dict["stage_coverage"]
    cc = eval_dict["confidence_calibration"]
    fc = eval_dict["failure_cause"]

    print("\n" + "=" * 60)
    print("  EVALUATION SUMMARY")
    print("=" * 60)
    print(f"  Samples evaluated : {oc.get('n_total', 0)}")
    print(f"  Accuracy          : {oc.get('accuracy', 0):.4f}")
    print(f"  Precision         : {oc.get('precision', 0):.4f}")
    print(f"  Recall            : {oc.get('recall', 0):.4f}")
    print(f"  F1 Score          : {oc.get('f1_score', 0):.4f}")
    cm = oc.get("confusion_matrix", {})
    if cm:
        print(f"\n  Confusion Matrix  (rows=GT, cols=Pred):")
        print(f"              Pred-Fail  Pred-Succ")
        mat = cm["matrix"]
        print(f"  GT-Fail   :    {mat[0][0]:4d}       {mat[0][1]:4d}")
        print(f"  GT-Succ   :    {mat[1][0]:4d}       {mat[1][1]:4d}")
    print(f"\n  Stage Coverage    : {sc.get('mean_stage_coverage', 0):.4f} ± {sc.get('std_stage_coverage', 0):.4f}")
    print(f"  ECE               : {cc.get('ece', 'N/A')}")
    print(f"  Mean Confidence   : {cc.get('mean_confidence_overall', 'N/A')}")
    print(f"  Failure Cause Acc : {fc.get('failure_cause_accuracy', 0):.4f} "
          f"({fc.get('n_cause_matched', 0)}/{fc.get('n_failure_samples', 0)})")
    print("=" * 60)


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python evaluate.py results.json")
        sys.exit(1)
    with open(sys.argv[1]) as f:
        data = json.load(f)
    results = data.get("results", data)
    ev = full_evaluation(results)
    print_summary(ev)
    print(json.dumps(ev, indent=2))
