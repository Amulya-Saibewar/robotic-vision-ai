import sys
import torch

lines = []

lines.append(f"Python version : {sys.version}")
lines.append(f"Torch version  : {torch.__version__}")
lines.append(f"CUDA available : {torch.cuda.is_available()}")

if torch.cuda.is_available():
    device_name = torch.cuda.get_device_name(0)
    free_mem, total_mem = torch.cuda.mem_get_info(0)
    lines.append(f"CUDA device    : {device_name}")
    lines.append(f"Free GPU mem   : {free_mem / 1e9:.2f} GB / {total_mem / 1e9:.2f} GB total")
else:
    lines.append("CUDA device    : N/A (running on CPU)")
    lines.append("Free GPU mem   : N/A")

output = "\n".join(lines)
print(output)

with open("setup_check.txt", "w") as f:
    f.write(output + "\n")
