"""Bypass the runner's try/except to see the real error."""
import json
import sys
import traceback
from pathlib import Path

import torch
import transformers

# Load 1 sample
samples = json.load(open("data/samples.json"))
sample = samples[0]
vid = sample["video_id"]
rgb_path = sample["rgb_path"]
print(f"Testing on: {vid}")
print(f"Video path: {rgb_path}")
print(f"Video exists: {Path(rgb_path).exists()}")
print(f"Video absolute: {Path(rgb_path).resolve()}")

# Load model
print("\n--- Loading model ---")
processor = transformers.AutoProcessor.from_pretrained("nvidia/Cosmos-Reason2-2B")
model = transformers.Qwen3VLForConditionalGeneration.from_pretrained(
    "nvidia/Cosmos-Reason2-2B",
    dtype=torch.float16,
    device_map="auto",
    attn_implementation="sdpa",
)
model.eval()
print("✓ Model loaded")

# Build minimal message
print("\n--- Building messages ---")
abs_path = Path(rgb_path).resolve()
messages = [
    {"role": "system", "content": [{"type": "text", "text": "You are a helpful assistant."}]},
    {"role": "user", "content": [
        {"type": "video", "video": f"file://{abs_path}", "fps": 4},
        {"type": "text", "text": "Describe what the robot does in one sentence."},
    ]},
]
print("✓ Messages ready")

# Process — THIS is where it likely fails
print("\n--- Calling apply_chat_template ---")
try:
    inputs = processor.apply_chat_template(
        messages,
        tokenize=True,
        add_generation_prompt=True,
        return_dict=True,
        return_tensors="pt",
        truncation=False,
        fps=4,
    )
    print("✓ Template applied; input_ids shape:", inputs["input_ids"].shape)
except Exception as e:
    print("\n✗ apply_chat_template FAILED:")
    traceback.print_exc()
    sys.exit(1)

inputs = inputs.to(model.device)

# Generate
print("\n--- Generating ---")
try:
    with torch.no_grad():
        out_ids = model.generate(**inputs, max_new_tokens=256, do_sample=False)
    prompt_len = inputs["input_ids"].shape[1]
    text = processor.decode(out_ids[0, prompt_len:], skip_special_tokens=True)
    print("\n=== MODEL OUTPUT ===")
    print(text)
    print("====================")
    print("\n✓ SUCCESS — Cosmos works end-to-end!")
except Exception as e:
    print("\n✗ generate FAILED:")
    traceback.print_exc()
