"""
Pydantic schema for robot-task predictions.
"""
from typing import Literal, Optional
from pydantic import BaseModel, Field


class Stage(BaseModel):
    name: Literal["approach", "align", "grasp", "lift", "move", "place", "idle"]
    start_s: float
    end_s: float


class Evidence(BaseModel):
    raft_vertical_drop_at_s: float
    depth_gap_to_target_mm: float
    explanation: str


class Prediction(BaseModel):
    video_id: str
    stages: list[Stage]
    outcome: Literal["success", "failure"]
    failure_cause: str = Field(
        description="Reason for failure. Cosmos may generate free-form text; we accept any string."
    )
    confidence: float = Field(ge=0.0, le=1.0)
    evidence: Evidence
