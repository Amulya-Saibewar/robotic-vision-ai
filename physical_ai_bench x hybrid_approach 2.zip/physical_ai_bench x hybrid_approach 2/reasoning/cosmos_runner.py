"""
Cosmos-Reason2-2B local inference for robot-task stage prediction.

Uses the OFFICIAL pattern from the model card:
  - transformers.Qwen3VLForConditionalGeneration  (NOT AutoModelForCausalLM)
  - transformers.AutoProcessor                    (Qwen3VLProcessor)
  - processor.apply_chat_template(..., tokenize=True, fps=4)
  - dtype=float16 + attn_implementation="sdpa"

NIM API removed.

Requirements:
  pip install --upgrade "transformers>=4.57.0" accelerate torch torchvision
  pip install qwen-vl-utils tenacity decord pillow

Authentication:
  huggingface-cli login   (then accept license at:
                           https://huggingface.co/nvidia/Cosmos-Reason2-2B)

Model is gated; if download fails the runner logs a warning and returns a
clearly-marked fallback prediction so the rest of the pipeline keeps running.
"""

from __future__ import annotations

import json
import re
import textwrap
import warnings
from pathlib import Path

import numpy as np
import os
from dotenv import load_dotenv
load_dotenv()
if not os.environ.get("HF_TOKEN"):
    raise SystemExit("HF_TOKEN not set — add it to your .env file")
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from config import COSMOS_MODEL, DEVICE, OUT_DIR
from reasoning.schema import Evidence, Prediction, Stage

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_TARGET_FPS     = 4          # model-recommended FPS
_MAX_NEW_TOKENS = 4096       # model-recommended; avoids CoT truncation
_MAX_RETRIES    = 3

# Module-level singletons
_processor = None
_model     = None
_model_ok  = None   # None=not tried, True=loaded, False=failed


# ---------------------------------------------------------------------------
# Model loader — official Cosmos-Reason2 pattern, with debug logging
# ---------------------------------------------------------------------------

def _load_local_model() -> bool:
    global _processor, _model, _model_ok
    if _model_ok is not None:
        return _model_ok

    try:
        import torch
        import transformers

        # --- 1. Version check -------------------------------------------------
        tv = transformers.__version__
        major, minor = int(tv.split(".")[0]), int(tv.split(".")[1])
        if (major, minor) < (4, 57):
            raise RuntimeError(
                f"transformers {tv} is too old for Cosmos-Reason2. "
                "Run: pip install --upgrade 'transformers>=4.57.0'"
            )
        print(f"  [cosmos] transformers version: {tv}", flush=True)

        # --- 2. Class availability check -------------------------------------
        if not hasattr(transformers, "Qwen3VLForConditionalGeneration"):
            raise RuntimeError(
                "transformers.Qwen3VLForConditionalGeneration not found. "
                "Install: pip install --upgrade 'transformers>=4.57.0'"
            )

        # --- 3. HF auth check -------------------------------------------------
        from huggingface_hub import whoami
        try:
            user_info = whoami()
            print(f"  [cosmos] HF user: {user_info.get('name', '?')}", flush=True)
        except Exception as e:
            raise RuntimeError(
                f"HuggingFace auth failed: {e}\n"
                "Run: huggingface-cli login\n"
                "Then accept license at: https://huggingface.co/nvidia/Cosmos-Reason2-2B"
            )

        # --- 4. Load processor + model ---------------------------------------
        print(f"  [cosmos] Loading processor for {COSMOS_MODEL}...", flush=True)
        _processor = transformers.AutoProcessor.from_pretrained(COSMOS_MODEL)

        print(f"  [cosmos] Loading model {COSMOS_MODEL} (fp16, sdpa)...", flush=True)
        _model = transformers.Qwen3VLForConditionalGeneration.from_pretrained(
            COSMOS_MODEL,
            dtype=torch.float16,            # use dtype, not torch_dtype (newer API)
            device_map="auto",
            attn_implementation="sdpa",
            low_cpu_mem_usage=True,
        )
        _model.eval()

        # --- 5. Memory report ------------------------------------------------
        if torch.cuda.is_available():
            mem_alloc = torch.cuda.memory_allocated() / 1e9
            print(f"  [cosmos] GPU memory allocated: {mem_alloc:.2f} GB", flush=True)

        _model_ok = True
        print("  [cosmos] ✓ Model ready\n", flush=True)

    except Exception as exc:
        import traceback
        print("\n" + "=" * 70)
        print("  [cosmos ERROR] Model load FAILED — full traceback:")
        print("=" * 70)
        traceback.print_exc()
        print("=" * 70 + "\n")
        warnings.warn(
            f"[cosmos] Could not load {COSMOS_MODEL}: {exc}\n"
            "Pipeline will continue with fallback stub predictions."
        )
        _model_ok = False

    return _model_ok


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

_SCHEMA_BLOCK = textwrap.dedent("""
    OUTPUT SCHEMA (strict JSON, no markdown):
    {
      "video_id": "<str>",
      "stages": [{"name": "<approach|align|grasp|lift|move|place|idle>",
                  "start_s": <float>, "end_s": <float>}],
      "outcome": "<success|failure>",
      "failure_cause": "<missed_grasp|dropped_object|collision|unstable_movement|incorrect_placement|timeout|blocked_path|none>",
      "confidence": <float 0-1>,
      "evidence": {
        "raft_vertical_drop_at_s": <float>,
        "depth_gap_to_target_mm":  <float>,
        "explanation": "<str>"
      }
    }
""").strip()

# Cosmos-Reason2 system prompt — model card recommends this exact CoT format
_SYSTEM_PROMPT = (
    "You are a robot-task verdict model. "
    "Analyse the provided video frames and numeric signals, then output ONLY valid "
    "JSON that conforms exactly to the schema below.\n\n"
    "Answer the question in the following format:\n"
    "<think>\nyour reasoning\n</think>\n\n"
    "<answer>\nyour JSON\n</answer>"
)


def build_user_text(
    video_id: str,
    motion: dict,
    depth: dict,
    vjepa_norm: float,
) -> str:
    clip_s = motion.get("n_frames", 121) / motion.get("fps", 30.0)

    signal_summary = textwrap.dedent(f"""
        VIDEO SIGNAL SUMMARY  (video_id={video_id}, clip_length={clip_s:.1f}s)
        -----------------------------------------------------------------------
        [RAFT optical flow]
          peak_vertical_drop : {motion.get('peak_vertical_drop', 0):.4f} px/frame
                               at t={motion.get('peak_time_s', 0):.2f}s
          lift_onset_s       : {motion.get('lift_onset_s')}
          place_onset_s      : {motion.get('place_onset_s')}
          activity_ratio     : {motion.get('activity_ratio', 0):.2f}
          mean_magnitude_avg : {motion.get('magnitude', {}).get('mean', 0):.4f} px/frame

        [Depth (pre-computed NPZ, unit={depth.get('unit','m')})]
          min_gripper_to_object_dist : {depth.get('min_gripper_to_object_distance', 0):.4f}
          min_distance_time_s        : {depth.get('min_distance_time_s', 0):.2f}s
          depth_gradient_at_grasp    : {depth.get('depth_gradient_at_grasp', 0):.4f} m/s
          depth_gap_to_target_mm     : {depth.get('depth_gap_to_target_mm', 0):.1f} mm

        [V-JEPA2 embedding]
          embedding_norm : {vjepa_norm:.4f}
        -----------------------------------------------------------------------
    """).strip()

    return f"{_SCHEMA_BLOCK}\n\n{signal_summary}\n\nNow analyse the video and output the JSON."


# ---------------------------------------------------------------------------
# Answer extraction & validation
# ---------------------------------------------------------------------------

def _extract_answer(text: str) -> str:
    """Pull content inside <answer>...</answer>; fallback to last {...} block."""
    m = re.search(r"<answer>(.*?)</answer>", text, re.DOTALL | re.IGNORECASE)
    if m:
        candidate = m.group(1).strip()
        # strip markdown fences if present
        candidate = re.sub(r"^```(?:json)?\s*", "", candidate)
        candidate = re.sub(r"\s*```$", "", candidate)
        return candidate.strip()
    blocks = re.findall(r"\{.*\}", text, re.DOTALL)
    return blocks[-1].strip() if blocks else text.strip()


def _validate(raw_json: str, video_id: str) -> Prediction:
    data = json.loads(raw_json)
    if "video_id" not in data:
        data["video_id"] = video_id
    return Prediction.model_validate(data)


# ---------------------------------------------------------------------------
# Local generation — official Qwen3VL pattern
# ---------------------------------------------------------------------------

def _generate_local(
    video_path: str,
    system_prompt: str,
    user_text: str,
) -> str:
    """
    Use the model's expected message format with a video file path and fps=4.
    The processor handles frame sampling internally.
    """
    import torch

    messages = [
        {
            "role": "system",
            "content": [{"type": "text", "text": system_prompt}],
        },
        {
            "role": "user",
            "content": [
                {"type": "video", "video": str(Path(video_path).resolve()), "fps": _TARGET_FPS},
                {"type": "text",  "text": user_text},
            ],
        },
    ]

    print(f"  [cosmos] processing video at fps={_TARGET_FPS}...", flush=True)
    inputs = _processor.apply_chat_template(
        messages,
        tokenize=True,
        add_generation_prompt=True,
        return_dict=True,
        return_tensors="pt",
        truncation=False,
        fps=_TARGET_FPS,
    )
    inputs = inputs.to(_model.device)

    print(f"  [cosmos] generating (max_new_tokens={_MAX_NEW_TOKENS})...", flush=True)
    with torch.no_grad():
        output_ids = _model.generate(
            **inputs,
            max_new_tokens=_MAX_NEW_TOKENS,
            do_sample=False,
        )

    # strip the prompt tokens
    prompt_len = inputs["input_ids"].shape[1]
    generated  = output_ids[0, prompt_len:]
    decoded = _processor.decode(generated, skip_special_tokens=True)
    print(f"  [cosmos] generated {len(decoded)} chars", flush=True)
    return decoded


# ---------------------------------------------------------------------------
# Fallback stub (model unavailable)
# ---------------------------------------------------------------------------

def _fallback_prediction(video_id: str, motion: dict, depth: dict) -> Prediction:
    """
    Best-effort stub from RAFT/depth heuristics when the model can't load.
    Marked with confidence=0.0 so it's obvious in the output.
    """
    lift   = motion.get("lift_onset_s")
    place  = motion.get("place_onset_s")
    clip_s = motion.get("n_frames", 121) / motion.get("fps", 30.0)

    stages: list[Stage] = [Stage(name="approach", start_s=0.0, end_s=clip_s * 0.2)]
    if lift is not None:
        stages.append(Stage(name="grasp", start_s=lift, end_s=lift + 0.5))
    if place is not None:
        stages.append(Stage(name="place", start_s=place, end_s=min(place + 0.5, clip_s)))
    stages.append(Stage(name="idle", start_s=clip_s * 0.9, end_s=clip_s))

    return Prediction(
        video_id=video_id,
        stages=stages,
        outcome="success" if place is not None else "failure",
        failure_cause="none" if place is not None else "missed_grasp",
        confidence=0.0,
        evidence=Evidence(
            raft_vertical_drop_at_s=motion.get("peak_time_s", 0.0),
            depth_gap_to_target_mm=depth.get("depth_gap_to_target_mm", 0.0),
            explanation="[FALLBACK – Cosmos model unavailable] "
                        "Prediction derived from RAFT/depth heuristics only.",
        ),
    )


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_cosmos(
    sample: dict,
    motion: dict,
    depth: dict,
    vjepa_norm: float,
    frames: np.ndarray = None,   # kept for signature compat with old pipeline.py
    fps: float = None,           # kept for signature compat
) -> Prediction:
    """
    Orchestrates prompt building, model call (with retries), schema validation,
    and file saves. Always returns a Prediction.

    Note: `frames` and `fps` are kept in the signature so the existing
    pipeline.py works unchanged, but the model now consumes the video file
    directly via the path in `sample['rgb_path']`.
    """
    video_id = sample["video_id"]
    rgb_path = sample["rgb_path"]
    out_raw  = Path(OUT_DIR) / "cosmos" / f"{video_id}_raw.txt"
    out_pred = Path(OUT_DIR) / "predictions" / f"{video_id}.json"
    out_raw.parent.mkdir(parents=True, exist_ok=True)
    out_pred.parent.mkdir(parents=True, exist_ok=True)

    user_text = build_user_text(video_id, motion, depth, vjepa_norm)

    # Try to load the model (lazy, cached)
    if not _load_local_model():
        warnings.warn(f"[cosmos] {video_id}: using fallback prediction")
        pred = _fallback_prediction(video_id, motion, depth)
        out_raw.write_text("[model unavailable – fallback prediction used]")
        out_pred.write_text(pred.model_dump_json(indent=2))
        print(f"  [cosmos] {video_id}: fallback saved → {out_pred}")
        return pred

    # Retry loop for schema-validation failures
    extra_instruction = ""
    raw_text = ""
    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            current_text = user_text + extra_instruction
            raw_text = _generate_local(rgb_path, _SYSTEM_PROMPT, current_text)
            answer = _extract_answer(raw_text)
            pred   = _validate(answer, video_id)

            out_raw.write_text(raw_text)
            out_pred.write_text(pred.model_dump_json(indent=2))
            print(f"  [cosmos] {video_id}: ✓ OK (attempt {attempt})  "
                  f"outcome={pred.outcome}  conf={pred.confidence:.2f}  → {out_pred}")
            return pred

        except (json.JSONDecodeError, ValueError) as exc:
            warnings.warn(f"[cosmos] {video_id} attempt {attempt} failed: {exc}")
            extra_instruction = (
                f"\n\nPREVIOUS ATTEMPT FAILED with: {exc}\n"
                "You MUST output ONLY a single JSON object wrapped in "
                "<answer>...</answer>. No extra text, no markdown."
            )
        except Exception as exc:
            # Hard error (CUDA OOM, processor error, etc.) — bail to fallback
            import traceback
            print(f"\n[cosmos] hard error on {video_id}, attempt {attempt}:")
            traceback.print_exc()
            break

    # All retries exhausted → fallback
    out_raw.write_text(raw_text or "[no output]")
    warnings.warn(f"[cosmos] {video_id}: all attempts failed, using fallback")
    pred = _fallback_prediction(video_id, motion, depth)
    out_pred.write_text(pred.model_dump_json(indent=2))
    return pred


# ---------------------------------------------------------------------------
# CLI: run on first N samples (default 1)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys as _sys

    manifest = Path("data/samples.json")
    with open(manifest) as fh:
        samples = json.load(fh)

    n = int(_sys.argv[1]) if len(_sys.argv) > 1 else 1

    for i, sample in enumerate(samples[:n]):
        vid = sample["video_id"]
        print(f"\n{'='*70}")
        print(f"  [{i+1}/{n}] {vid}")
        print('=' * 70)

        # Load pre-computed signal JSONs
        motion_path = Path(OUT_DIR) / "motion" / f"{vid}.json"
        depth_path  = Path(OUT_DIR) / "depth"  / f"{vid}.json"
        vjepa_path  = Path(OUT_DIR) / "vjepa"  / f"{vid}.npy"

        with open(motion_path) as fh: motion = json.load(fh)
        with open(depth_path)  as fh: depth  = json.load(fh)
        vjepa_norm = (
            float(np.linalg.norm(np.load(str(vjepa_path))))
            if vjepa_path.exists() else 0.0
        )

        pred = run_cosmos(sample, motion, depth, vjepa_norm)

        print(f"\n  RESULT:")
        print(f"    outcome       : {pred.outcome}")
        print(f"    failure_cause : {pred.failure_cause}")
        print(f"    confidence    : {pred.confidence:.2f}")
        print(f"    stages        : {[(s.name, s.start_s, s.end_s) for s in pred.stages]}")
        print(f"    explanation   : {pred.evidence.explanation[:120]}...")

        re_validated = Prediction.model_validate_json(pred.model_dump_json())
        print(f"    schema valid  : ✓ (video_id={re_validated.video_id})")