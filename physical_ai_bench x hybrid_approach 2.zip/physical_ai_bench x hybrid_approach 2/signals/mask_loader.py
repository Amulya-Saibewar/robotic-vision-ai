"""
Load RGB frames and SAM2 masks from downloaded samples.
No SAM2 model is run here — pkl files are pre-computed offline masks.
"""

import pickle
import warnings
from pathlib import Path

import cv2
import numpy as np

_PRINTED_PKL_STRUCTURE = False   # print pkl structure only once across the session


# ---------------------------------------------------------------------------
# 1. Video loader
# ---------------------------------------------------------------------------

def load_video(rgb_path: str) -> tuple[np.ndarray, float]:
    """
    Returns (frames: uint8 (T, H, W, 3), fps: float).
    Tries decord first; falls back to cv2.VideoCapture.
    """
    try:
        from decord import VideoReader, cpu
        vr  = VideoReader(str(rgb_path), ctx=cpu(0))
        fps = float(vr.get_avg_fps())
        frames = vr.get_batch(list(range(len(vr)))).asnumpy()  # (T, H, W, 3) RGB
        return frames, fps
    except Exception as decord_err:
        warnings.warn(f"decord failed ({decord_err}), falling back to cv2")

    cap    = cv2.VideoCapture(str(rgb_path))
    fps    = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frames = []
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    cap.release()
    return np.stack(frames, axis=0).astype(np.uint8), fps


# ---------------------------------------------------------------------------
# 2. Mask loader
# ---------------------------------------------------------------------------

def _decode_coco_rle_3d(rle_entry: dict) -> np.ndarray:
    """
    Decode a single object's 3-D COCO RLE mask.
    rle_entry = {'data': {'size': [T*H*W, 1], 'counts': bytes},
                 'mask_shape': [T, H, W]}
    Returns bool (T, H, W).
    """
    from pycocotools import mask as cocomask
    T, H, W = rle_entry["mask_shape"]
    decoded = cocomask.decode(rle_entry["data"])   # (T*H*W, 1) uint8
    return decoded[:, 0].reshape(T, H, W).astype(bool)


def load_masks_pkl(pkl_path: str) -> np.ndarray:
    """
    Returns masks: bool (T, H, W).

    Handles formats found in sam2_pkls/:
      d) list of per-object dicts { 'phrase': str,
                                    'segmentation_mask_rle': {
                                        'data': {'size': [...], 'counts': bytes},
                                        'mask_shape': [T, H, W] } }
         → decode each object's 3-D COCO RLE, union over objects.
      a) dict  { object_id: np.ndarray (T, H, W[, 1]) }  → union over objects
      b) list  [ {"segmentation": (H, W), ...}, ... ]    → stack frames
      c) np.ndarray (T, H, W) or (T, H, W, 1)           → use directly
    """
    global _PRINTED_PKL_STRUCTURE

    with open(pkl_path, "rb") as fh:
        obj = pickle.load(fh)

    if not _PRINTED_PKL_STRUCTURE:
        print(f"  [pkl] type={type(obj)}", end="")
        if isinstance(obj, dict):
            print(f"  keys[:5]={list(obj.keys())[:5]}")
            first_val = next(iter(obj.values()))
            print(f"  [pkl] value type={type(first_val)}, "
                  f"shape={getattr(first_val, 'shape', '?')}, "
                  f"dtype={getattr(first_val, 'dtype', '?')}")
        elif isinstance(obj, list):
            print(f"  len={len(obj)}")
            if obj and isinstance(obj[0], dict):
                print(f"  [pkl] item[0] keys={list(obj[0].keys())[:5]}")
                # show rle sub-structure if present
                if "segmentation_mask_rle" in obj[0]:
                    rle = obj[0]["segmentation_mask_rle"]
                    print(f"  [pkl] segmentation_mask_rle keys={list(rle.keys())}  "
                          f"mask_shape={rle.get('mask_shape')}")
        elif isinstance(obj, np.ndarray):
            print(f"  shape={obj.shape}  dtype={obj.dtype}")
        else:
            print()
        _PRINTED_PKL_STRUCTURE = True

    # --- format d: list of per-object dicts with COCO 3-D RLE ---
    if (isinstance(obj, list) and obj
            and isinstance(obj[0], dict)
            and "segmentation_mask_rle" in obj[0]):
        arrays = [_decode_coco_rle_3d(item["segmentation_mask_rle"]) for item in obj]
        return np.any(np.stack(arrays, axis=0), axis=0)   # (T, H, W)

    # --- format a: dict of per-object arrays ---
    if isinstance(obj, dict):
        arrays = []
        for arr in obj.values():
            arr = np.asarray(arr)
            if arr.ndim == 4:          # (T, H, W, 1)
                arr = arr[..., 0]
            arrays.append(arr.astype(bool))
        return np.any(np.stack(arrays, axis=0), axis=0)   # (T, H, W)

    # --- format b: list of per-frame dicts ---
    if isinstance(obj, list):
        frames = []
        for item in obj:
            if isinstance(item, dict):
                seg = item.get("segmentation", item.get("mask", None))
                if seg is None:
                    seg = next((v for v in item.values()
                                if isinstance(v, np.ndarray)), None)
                frames.append(np.asarray(seg).astype(bool))
            else:
                frames.append(np.asarray(item).astype(bool))
        masks = np.stack(frames, axis=0)   # (T, H, W)
        if masks.ndim == 4:
            masks = masks[..., 0]
        return masks

    # --- format c: raw ndarray ---
    if isinstance(obj, np.ndarray):
        masks = obj
        if masks.ndim == 4:
            masks = masks[..., 0]
        return masks.astype(bool)

    raise ValueError(f"Unknown pkl format: {type(obj)}")


# ---------------------------------------------------------------------------
# 3. Temporal alignment
# ---------------------------------------------------------------------------

def align(frames: np.ndarray, masks: np.ndarray) -> np.ndarray:
    """
    Nearest-neighbour resample `masks` along T axis to match len(frames).
    """
    T_f, T_m = len(frames), len(masks)
    if T_f == T_m:
        return masks
    indices = np.round(np.linspace(0, T_m - 1, T_f)).astype(int)
    return masks[indices]


# ---------------------------------------------------------------------------
# 4. Preview saver
# ---------------------------------------------------------------------------

def preview(video_id: str, frames: np.ndarray, masks: np.ndarray) -> None:
    """
    Saves data/preview/<video_id>.png with three panels:
      frame[0]  |  mask overlay (frame[0])  |  frame[T//2]
    """
    preview_dir = Path("data/preview")
    preview_dir.mkdir(parents=True, exist_ok=True)

    T = len(frames)
    f0   = frames[0].copy()
    fmid = frames[T // 2].copy()
    m0   = masks[0]

    # Red tint where mask is True on frame 0
    overlay = f0.copy()
    overlay[m0] = (overlay[m0] * 0.4 + np.array([220, 30, 30]) * 0.6).clip(0, 255).astype(np.uint8)

    def to_bgr(img):
        return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

    canvas = np.concatenate([to_bgr(f0), to_bgr(overlay), to_bgr(fmid)], axis=1)
    out_path = preview_dir / f"{video_id}.png"
    cv2.imwrite(str(out_path), canvas)
    print(f"  [preview] saved → {out_path}")


# ---------------------------------------------------------------------------
# CLI test: run on first 3 samples from data/samples.json
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json

    manifest_path = Path("data/samples.json")
    if not manifest_path.exists():
        raise FileNotFoundError("Run signals/dataset.py first to download samples.")

    with open(manifest_path) as fh:
        samples = json.load(fh)

    for sample in samples[:3]:
        vid = sample["video_id"]
        print(f"\n=== {vid} ===")

        frames, fps = load_video(sample["rgb_path"])
        print(f"  frames : {frames.shape}  dtype={frames.dtype}  fps={fps:.2f}")

        masks = load_masks_pkl(sample["sam2_pkl_path"])
        print(f"  masks  : {masks.shape}  dtype={masks.dtype}")

        masks = align(frames, masks)
        print(f"  aligned: {masks.shape}")

        coverage = masks.mean() * 100
        print(f"  mean mask coverage: {coverage:.2f}%")

        preview(vid, frames, masks)
