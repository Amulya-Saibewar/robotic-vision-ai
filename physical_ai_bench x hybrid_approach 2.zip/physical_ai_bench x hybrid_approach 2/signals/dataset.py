"""
Download 20 robotic-arm samples from shi-labs/physical-ai-bench-conditional-generation.

Dataset structure (all 600 tasks are robotic-arm clips):
  videos/task_XXXX.mp4
  depth_npzs/task_XXXX.npz
  sam2_pkls/task_XXXX.pkl
  captions/task_XXXX.json  →  {"caption": "..."}

Saved locally as:
  data/samples/<task_id>/{rgb.mp4, depth.npz, sam2.pkl, caption.txt}
"""

import json
import os
import pickle
import shutil
from pathlib import Path
from typing import Optional

from huggingface_hub import hf_hub_download
from tqdm import tqdm

from config import DATA_DIR, DATASET_NAME, N_SAMPLES

REPO_ID   = DATASET_NAME
REPO_TYPE = "dataset"

_MODALITIES = {
    "rgb"    : ("videos",     "{}.mp4",  "rgb.mp4"),
    "depth"  : ("depth_npzs", "{}.npz",  "depth.npz"),
    "sam2"   : ("sam2_pkls",  "{}.pkl",  "sam2.pkl"),
    "caption": ("captions",   "{}.json", "caption.json"),
}


def _hf_path(folder: str, filename: str) -> str:
    return f"{folder}/{filename}"


def _download_one(task_id: str, out_dir: Path) -> Optional[dict]:
    """
    Download all four modalities for `task_id`.
    Returns a sample dict on success, None if any modality is missing.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {}

    for key, (folder, tmpl, local_name) in _MODALITIES.items():
        repo_path   = _hf_path(folder, tmpl.format(task_id))
        local_path  = out_dir / local_name
        try:
            cached = hf_hub_download(
                repo_id=REPO_ID,
                filename=repo_path,
                repo_type=REPO_TYPE,
                local_dir=None,   # use HF cache; copy below
            )
            shutil.copy2(cached, local_path)
            paths[key] = local_path
        except Exception as exc:
            print(f"  [skip] {task_id}: missing {repo_path} ({exc})")
            return None

    # Parse caption JSON → plain text
    with open(paths["caption"]) as fh:
        cap_data = json.load(fh)
    caption_text = cap_data.get("caption", "")
    caption_txt_path = out_dir / "caption.txt"
    caption_txt_path.write_text(caption_text)

    return {
        "video_id"       : task_id,
        "rgb_path"       : str(paths["rgb"]),
        "depth_npz_path" : str(paths["depth"]),
        "sam2_pkl_path"  : str(paths["sam2"]),
        "caption_path"   : str(caption_txt_path),
        "caption_text"   : caption_text,
    }


def download_samples(n: int = N_SAMPLES) -> list[dict]:
    samples_root = Path(DATA_DIR) / "samples"
    samples_root.mkdir(parents=True, exist_ok=True)

    results   = []
    candidate = 0       # task index counter (task_0000, task_0001, …)
    max_id    = 599     # dataset has task_0000 – task_0599

    with tqdm(total=n, desc="Downloading samples") as pbar:
        while len(results) < n and candidate <= max_id:
            task_id = f"task_{candidate:04d}"
            out_dir = samples_root / task_id

            sample = _download_one(task_id, out_dir)
            if sample is not None:
                results.append(sample)
                pbar.update(1)
                pbar.set_postfix({"last": task_id})
            candidate += 1

    if len(results) < n:
        print(f"Warning: only found {len(results)} complete samples (wanted {n}).")

    manifest_path = Path(DATA_DIR) / "samples.json"
    with open(manifest_path, "w") as fh:
        json.dump(results, fh, indent=2)
    print(f"\nManifest saved → {manifest_path}")

    return results


if __name__ == "__main__":
    samples = download_samples()
    print(f"\n{'ID':<15} {'Caption preview'}")
    print("-" * 80)
    for s in samples:
        preview = s["caption_text"][:80].replace("\n", " ")
        print(f"{s['video_id']:<15} {preview}")
