"""
Depth-based features for robot-task clips.

Primary path  : read pre-computed depth_npzs/<task>.npz  (always tried first)
Fallback path : Depth Anything V2-Small  (lazy-loaded only when .npz missing/corrupt)

Depth unit heuristic: if max value > 100 → metres (stored × 1000, i.e. mm),
                      otherwise already in metres.
All outputs are stored in metres; internal mm-converted values noted explicitly.
"""

import json
from pathlib import Path

import numpy as np

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from config import DEVICE, OUT_DIR

# Depth-Anything fallback (loaded lazily on first use)
_da_processor = None
_da_model      = None
_DA_MODEL_ID   = "depth-anything/Depth-Anything-V2-Small-hf"
_DA_BATCH       = 4


# ---------------------------------------------------------------------------
# 1.  Load depth from NPZ  (primary path)
# ---------------------------------------------------------------------------

def load_depth_npz(path: str) -> tuple[np.ndarray, str]:
    """
    Returns (depth: float32 (T, H, W), unit: "m" | "mm").
    The array key inside the file is always 'data' for this dataset.
    """
    data = np.load(path)
    if "data" not in data.files:
        raise KeyError(f"Expected key 'data' in {path}, got {data.files}")
    depth = data["data"].astype(np.float32)
    unit  = "mm" if depth.max() > 100.0 else "m"
    return depth, unit


# ---------------------------------------------------------------------------
# 2.  Fallback: Depth Anything V2 (lazy)
# ---------------------------------------------------------------------------

def _ensure_da_model():
    global _da_processor, _da_model
    if _da_model is not None:
        return
    print("  [depth] loading Depth Anything V2-Small (fallback) …", flush=True)
    from transformers import AutoImageProcessor, AutoModelForDepthEstimation
    import torch
    _da_processor = AutoImageProcessor.from_pretrained(_DA_MODEL_ID)
    _da_model     = (
        AutoModelForDepthEstimation
        .from_pretrained(_DA_MODEL_ID)
        .eval()
        .to(DEVICE)
    )


def _infer_depth_da(frames: np.ndarray) -> np.ndarray:
    """
    frames: (T, H, W, 3) uint8 numpy.
    Returns: depth (T, H, W) float32 in relative units (normalised to [0,1]).
    """
    import torch
    from PIL import Image

    _ensure_da_model()
    T = len(frames)
    depths = []

    for start in range(0, T, _DA_BATCH):
        batch_frames = frames[start : start + _DA_BATCH]
        pil_imgs = [Image.fromarray(f) for f in batch_frames]
        inputs = _da_processor(images=pil_imgs, return_tensors="pt")
        inputs = {k: v.to(DEVICE) for k, v in inputs.items()}
        with torch.no_grad():
            out = _da_model(**inputs)
        # predicted_depth: (B, H', W') — interpolate back to original size
        pred = out.predicted_depth   # (B, H', W')
        H, W = frames.shape[1], frames.shape[2]
        pred_up = torch.nn.functional.interpolate(
            pred.unsqueeze(1), size=(H, W), mode="bilinear", align_corners=False
        ).squeeze(1)                  # (B, H, W)
        depths.append(pred_up.cpu().numpy())

    depth = np.concatenate(depths, axis=0).astype(np.float32)
    # normalise per-clip to [0, 1] so downstream code treats it as relative metres
    dmin, dmax = depth.min(), depth.max()
    if dmax > dmin:
        depth = (depth - dmin) / (dmax - dmin)
    return depth


# ---------------------------------------------------------------------------
# 3.  Load depth — unified entry point
# ---------------------------------------------------------------------------

def load_depth(npz_path: str, frames: np.ndarray | None = None) -> tuple[np.ndarray, str, str]:
    """
    Try the .npz first.  Fall back to Depth Anything V2 if unavailable.
    Returns (depth: float32 (T, H, W), unit: str, source: "npz" | "depth_anything").
    `frames` only needed for the fallback path.
    """
    try:
        depth, unit = load_depth_npz(npz_path)
        return depth, unit, "npz"
    except Exception as exc:
        print(f"  [depth] npz failed ({exc}), using Depth Anything V2 fallback")
        if frames is None:
            raise RuntimeError("frames required for Depth Anything fallback") from exc
        depth = _infer_depth_da(frames)
        return depth, "m", "depth_anything"


# ---------------------------------------------------------------------------
# 4.  Feature extraction
# ---------------------------------------------------------------------------

def extract_depth_features(
    depth_maps: np.ndarray,   # (T, H, W) float32
    masks: np.ndarray,         # (T, H, W) bool
    fps: float,
    unit: str = "m",
) -> dict:
    """
    Per-frame features:
      object_depth_t         – mean depth of masked region
      gripper_proxy_t        – mean depth in 32×32 patch centred on mask centroid
      gripper_to_object_t    – |gripper_proxy_t − object_depth_t|

    Aggregated scalars:
      min_gripper_to_object_distance   – closest approach (same unit as input)
      min_distance_time_s
      depth_gradient_at_grasp          – d(object_depth)/dt around closest-approach frame
      depth_gap_to_target_mm           – object_depth[-1] − min(object_depth_last_30%)
                                         (always in mm; converted if unit=="m")
    """
    T, H, W = depth_maps.shape
    times_s = np.arange(T) / fps

    obj_depth_ts   = []
    grip_proxy_ts  = []
    g2o_ts         = []

    PATCH = 16   # half-width of gripper proxy patch (32×32 total)

    for t in range(T):
        m = masks[t]
        d = depth_maps[t]

        # object depth: mean inside mask
        pix = d[m]
        obj_d = float(pix.mean()) if pix.size else float(d.mean())

        # gripper proxy: 32×32 patch around mask centroid
        if m.any():
            rows, cols = np.where(m)
            cy, cx = int(rows.mean()), int(cols.mean())
        else:
            cy, cx = H // 2, W // 2
        r0, r1 = max(cy - PATCH, 0), min(cy + PATCH, H)
        c0, c1 = max(cx - PATCH, 0), min(cx + PATCH, W)
        grip_d = float(d[r0:r1, c0:c1].mean())

        obj_depth_ts.append(obj_d)
        grip_proxy_ts.append(grip_d)
        g2o_ts.append(abs(grip_d - obj_d))

    obj_arr  = np.array(obj_depth_ts,  dtype=np.float32)
    grip_arr = np.array(grip_proxy_ts, dtype=np.float32)
    g2o_arr  = np.array(g2o_ts,        dtype=np.float32)

    # closest approach
    min_idx      = int(np.argmin(g2o_arr))
    min_g2o      = float(g2o_arr[min_idx])
    min_g2o_time = float(times_s[min_idx])

    # depth gradient at grasp: central difference around min_idx (window ±2 frames)
    lo = max(0, min_idx - 2)
    hi = min(T - 1, min_idx + 2)
    dt = (hi - lo) / fps
    depth_grad = float((obj_arr[hi] - obj_arr[lo]) / dt) if dt > 0 else 0.0

    # depth gap to target (last 30% of clip)
    last30_start = int(T * 0.70)
    last30_depth = obj_arr[last30_start:]
    to_mm = 1000.0 if unit == "m" else 1.0
    depth_gap_mm = float((obj_arr[-1] - last30_depth.min()) * to_mm)

    return {
        "unit":                           unit,
        "n_frames":                       T,
        "fps":                            fps,
        # per-frame timeseries
        "object_depth":                   [round(float(v), 4) for v in obj_arr],
        "gripper_proxy_depth":            [round(float(v), 4) for v in grip_arr],
        "gripper_to_object_dist":         [round(float(v), 4) for v in g2o_arr],
        # scalars
        "min_gripper_to_object_distance": round(min_g2o, 4),
        "min_distance_time_s":            round(min_g2o_time, 4),
        "depth_gradient_at_grasp":        round(depth_grad, 4),
        "depth_gap_to_target_mm":         round(depth_gap_mm, 4),
    }


# ---------------------------------------------------------------------------
# 5.  Save helper
# ---------------------------------------------------------------------------

def save_depth_json(video_id: str, features: dict, source: str,
                    out_dir: str = OUT_DIR) -> Path:
    out_path = Path(out_dir) / "depth" / f"{video_id}.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"video_id": video_id, "source": source, **features}
    with open(out_path, "w") as fh:
        json.dump(payload, fh, indent=2)
    return out_path


# ---------------------------------------------------------------------------
# CLI: run on all samples (or first N passed as argv)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys as _sys
    from signals.mask_loader import load_video, load_masks_pkl, align

    manifest = Path("data/samples.json")
    with open(manifest) as fh:
        samples = json.load(fh)

    n = int(_sys.argv[1]) if len(_sys.argv) > 1 else len(samples)
    samples = samples[:n]

    all_results = []
    for i, sample in enumerate(samples):
        vid = sample["video_id"]
        out = Path(OUT_DIR) / "depth" / f"{vid}.json"
        if out.exists():
            print(f"[{i+1:02d}/{n}] {vid} – cached")
            with open(out) as fh:
                all_results.append(json.load(fh))
            continue

        print(f"[{i+1:02d}/{n}] {vid} …", flush=True)
        frames, fps = load_video(sample["rgb_path"])
        masks       = load_masks_pkl(sample["sam2_pkl_path"])
        masks       = align(frames, masks)

        depth, unit, source = load_depth(sample["depth_npz_path"], frames)

        # confirm on first sample
        if i == 0:
            print(f"  [depth] example frame 0: min={depth[0].min():.3f} "
                  f"max={depth[0].max():.3f} unit={unit}")

        feat = extract_depth_features(depth, masks, fps, unit=unit)
        path = save_depth_json(vid, feat, source)
        all_results.append({"video_id": vid, "source": source, **feat})

        print(f"  source={source}  unit={unit}  "
              f"min_g2o={feat['min_gripper_to_object_distance']:.4f}{unit} "
              f"at t={feat['min_distance_time_s']:.2f}s  "
              f"gap_mm={feat['depth_gap_to_target_mm']:.1f}  → {path}")

    # combined summary
    summary = []
    for r in all_results:
        summary.append({
            "video_id":                       r["video_id"],
            "source":                         r.get("source", "npz"),
            "unit":                           r.get("unit", "m"),
            "min_gripper_to_object_distance": r["min_gripper_to_object_distance"],
            "min_distance_time_s":            r["min_distance_time_s"],
            "depth_gradient_at_grasp":        r["depth_gradient_at_grasp"],
            "depth_gap_to_target_mm":         r["depth_gap_to_target_mm"],
        })
    sum_path = Path(OUT_DIR) / "depth" / "summary.json"
    with open(sum_path, "w") as fh:
        json.dump(summary, fh, indent=2)
    print(f"\nSummary saved → {sum_path}")
