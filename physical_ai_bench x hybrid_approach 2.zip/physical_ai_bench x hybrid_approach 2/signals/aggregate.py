"""
Merge per-video motion and depth JSONs into a single flat feature vector
per clip, saved to outputs/features/<video_id>.json and a combined
outputs/features/all_features.json.

All timeseries are reduced to compact statistics so the output is
fixed-length and directly usable by the reasoning layer.
"""

import json
import statistics
from pathlib import Path

import numpy as np

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from config import OUT_DIR


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _stats(ts: list[float]) -> dict:
    """Return mean/std/min/max/p25/p75 for a timeseries."""
    if not ts:
        return dict(mean=0.0, std=0.0, min=0.0, max=0.0, p25=0.0, p75=0.0)
    a = np.array(ts, dtype=np.float32)
    return {
        "mean": round(float(a.mean()), 5),
        "std":  round(float(a.std()),  5),
        "min":  round(float(a.min()),  5),
        "max":  round(float(a.max()),  5),
        "p25":  round(float(np.percentile(a, 25)), 5),
        "p75":  round(float(np.percentile(a, 75)), 5),
    }


def _slope(ts: list[float], fps: float) -> float:
    """Least-squares slope of a timeseries (units/s)."""
    if len(ts) < 2:
        return 0.0
    t = np.arange(len(ts)) / fps
    p = np.polyfit(t, ts, 1)
    return round(float(p[0]), 5)


def _activity_ratio(mag: list[float], threshold: float = 0.1) -> float:
    """Fraction of frames with mean_magnitude above threshold."""
    if not mag:
        return 0.0
    return round(sum(v > threshold for v in mag) / len(mag), 4)


# ---------------------------------------------------------------------------
# Core aggregation
# ---------------------------------------------------------------------------

def aggregate(motion: dict, depth: dict) -> dict:
    """
    Combine one video's motion + depth dicts into a flat feature dict.
    """
    fps  = float(motion.get("fps", 30.0))
    vid  = motion["video_id"]

    mag   = motion.get("mean_magnitude",  [])
    vert  = motion.get("vertical_flow",   [])
    divg  = motion.get("divergence",      [])
    odep  = depth.get("object_depth",     [])
    gdep  = depth.get("gripper_proxy_depth", [])
    g2o   = depth.get("gripper_to_object_dist", [])

    # ---- motion stats ----
    mag_stats   = _stats(mag)
    vert_stats  = _stats(vert)
    divg_stats  = _stats(divg)

    # ---- depth stats ----
    odep_stats  = _stats(odep)
    g2o_stats   = _stats(g2o)

    # ---- cross-signal features ----
    # correlation between magnitude and gripper-to-object closing rate
    if len(mag) >= 2 and len(g2o) >= 2:
        n = min(len(mag), len(g2o))
        corr = float(np.corrcoef(mag[:n], g2o[:n])[0, 1])
        if np.isnan(corr):
            corr = 0.0
    else:
        corr = 0.0

    # depth change from start to end of clip
    odep_delta = round(float(odep[-1] - odep[0]), 5) if len(odep) >= 2 else 0.0

    # early vs late motion energy ratio (first 30% vs last 30%)
    split = max(1, len(mag) // 3)
    early_energy = float(np.mean(mag[:split]))  if mag else 0.0
    late_energy  = float(np.mean(mag[-split:])) if mag else 0.0
    energy_ratio = round(late_energy / early_energy, 4) if early_energy > 1e-6 else 0.0

    return {
        "video_id": vid,
        "n_frames": motion.get("n_frames", 0),
        "fps":      fps,
        # --- motion scalars (from raft_motion) ---
        "peak_vertical_drop":           motion.get("peak_vertical_drop", 0.0),
        "peak_time_s":                  motion.get("peak_time_s", 0.0),
        "lift_onset_s":                 motion.get("lift_onset_s"),
        "place_onset_s":                motion.get("place_onset_s"),
        "activity_ratio":               _activity_ratio(mag),
        "motion_slope":                 _slope(mag, fps),
        "energy_ratio_late_early":      energy_ratio,
        # --- motion timeseries stats ---
        "magnitude":                    mag_stats,
        "vertical_flow":                vert_stats,
        "divergence":                   divg_stats,
        # --- depth scalars (from depth_features) ---
        "depth_source":                 depth.get("source", "npz"),
        "depth_unit":                   depth.get("unit", "m"),
        "min_gripper_to_object_dist":   depth.get("min_gripper_to_object_distance", 0.0),
        "min_distance_time_s":          depth.get("min_distance_time_s", 0.0),
        "depth_gradient_at_grasp":      depth.get("depth_gradient_at_grasp", 0.0),
        "depth_gap_to_target_mm":       depth.get("depth_gap_to_target_mm", 0.0),
        "object_depth_delta_m":         odep_delta,
        "object_depth_slope":           _slope(odep, fps),
        # --- depth timeseries stats ---
        "object_depth":                 odep_stats,
        "gripper_to_object":            g2o_stats,
        # --- cross-signal ---
        "mag_g2o_correlation":          round(corr, 5),
    }


# ---------------------------------------------------------------------------
# Load helpers
# ---------------------------------------------------------------------------

def load_motion(video_id: str, out_dir: str = OUT_DIR) -> dict:
    p = Path(out_dir) / "motion" / f"{video_id}.json"
    with open(p) as f:
        return json.load(f)


def load_depth_feat(video_id: str, out_dir: str = OUT_DIR) -> dict:
    p = Path(out_dir) / "depth" / f"{video_id}.json"
    with open(p) as f:
        return json.load(f)


def save_features(video_id: str, features: dict, out_dir: str = OUT_DIR) -> Path:
    out = Path(out_dir) / "features" / f"{video_id}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w") as f:
        json.dump(features, f, indent=2)
    return out


# ---------------------------------------------------------------------------
# CLI: aggregate all available results
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys as _sys

    manifest = Path("data/samples.json")
    with open(manifest) as f:
        samples = json.load(f)

    n = int(_sys.argv[1]) if len(_sys.argv) > 1 else len(samples)
    all_feats = []
    missing   = []

    for i, sample in enumerate(samples[:n]):
        vid = sample["video_id"]
        out = Path(OUT_DIR) / "features" / f"{vid}.json"
        if out.exists():
            print(f"[{i+1:02d}/{n}] {vid} – cached")
            with open(out) as f:
                all_feats.append(json.load(f))
            continue

        try:
            motion = load_motion(vid)
            depth  = load_depth_feat(vid)
        except FileNotFoundError as e:
            print(f"[{i+1:02d}/{n}] {vid} – SKIP (missing upstream: {e})")
            missing.append(vid)
            continue

        feat = aggregate(motion, depth)
        path = save_features(vid, feat)
        all_feats.append(feat)

        print(
            f"[{i+1:02d}/{n}] {vid}  "
            f"activity={feat['activity_ratio']:.2f}  "
            f"lift={feat['lift_onset_s']}  "
            f"place={feat['place_onset_s']}  "
            f"mag_mean={feat['magnitude']['mean']:.4f}  "
            f"g2o_min={feat['min_gripper_to_object_dist']:.4f}  "
            f"→ {path}"
        )

    # combined table
    all_path = Path(OUT_DIR) / "features" / "all_features.json"
    with open(all_path, "w") as f:
        json.dump(all_feats, f, indent=2)
    print(f"\nCombined features → {all_path}  ({len(all_feats)} clips)")
    if missing:
        print(f"Skipped (missing upstream): {missing}")
