"""
Video embeddings using V-JEPA 2 (encoder only, no predictor).

Model priority:
  1. facebook/vjepa2-vitl-fpc64-256   (ViT-L, d=1024)
  2. facebook/vjepa2-vitl-fpc16-256-ssv2  (ViT-L fine-tuned, d=1024)
  3. facebook/vjepa2-vitg-fpc64-256   (ViT-g, d=1408  – large but available)

Fallback on any load error: zeros(1024) with a warning.

embed_video(frames) → np.ndarray (d,)
  - samples 16 frames uniformly
  - runs VJEPA2VideoProcessor normalisation (resize→256, centre-crop, [-1,1] norm)
  - forward pass with skip_predictor=True → encoder last_hidden_state (B, N, d)
  - mean-pool over patch tokens → (d,)
"""

import json
import warnings
from pathlib import Path

import numpy as np
import torch

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from config import DEVICE, OUT_DIR

# ---------------------------------------------------------------------------
# Model registry  (tried in order until one loads)
# ---------------------------------------------------------------------------

_MODEL_CANDIDATES = [
    ("facebook/vjepa2-vitl-fpc64-256",       1024),
    ("facebook/vjepa2-vitl-fpc16-256-ssv2",  1024),
    ("facebook/vjepa2-vitg-fpc64-256",       1408),
]
_FALLBACK_DIM = 1024

# module-level singletons, populated on first call to embed_video
_processor   = None
_model       = None
_embed_dim   = _FALLBACK_DIM
_model_id    = None
_load_failed = False


def _load_model() -> bool:
    """
    Try each candidate in order.  Populates module globals on success.
    Returns True on success, False if all fail.
    """
    global _processor, _model, _embed_dim, _model_id, _load_failed

    from transformers import VJEPA2VideoProcessor, VJEPA2Model

    for model_id, dim in _MODEL_CANDIDATES:
        try:
            print(f"  [vjepa] loading {model_id} …", flush=True)
            _processor = VJEPA2VideoProcessor.from_pretrained(model_id)
            _model     = (
                VJEPA2Model.from_pretrained(model_id)
                .eval()
                .to(DEVICE)
            )
            _embed_dim = dim
            _model_id  = model_id
            print(f"  [vjepa] loaded {model_id}  d={dim}  device={DEVICE}")
            return True
        except Exception as exc:
            warnings.warn(f"[vjepa] {model_id} failed: {exc}")

    _load_failed = True
    warnings.warn(
        "[vjepa] ALL model candidates failed. "
        f"embed_video will return zeros({_FALLBACK_DIM})."
    )
    return False


def _ensure_loaded():
    global _load_failed
    if _model is not None or _load_failed:
        return
    _load_model()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

N_FRAMES = 16   # frames sampled per clip


def embed_video(frames: np.ndarray) -> np.ndarray:
    """
    frames: (T, H, W, 3) uint8 numpy array.
    Returns: embedding vector (d,) float32.
    """
    _ensure_loaded()

    if _load_failed:
        warnings.warn("[vjepa] using zero-fallback embedding")
        return np.zeros(_FALLBACK_DIM, dtype=np.float32)

    T = len(frames)
    idx = np.linspace(0, T - 1, N_FRAMES, dtype=int)
    sampled = [frames[i] for i in idx]          # list of N_FRAMES HWC uint8 arrays

    # Processor expects a list-of-frames (one video)
    inputs = _processor(
        videos=[sampled],
        num_frames=N_FRAMES,
        return_tensors="pt",
    )
    pv = inputs["pixel_values_videos"].to(DEVICE)   # (1, N_FRAMES, 3, 256, 256)

    with torch.no_grad():
        out = _model(pixel_values_videos=pv, skip_predictor=True)

    # last_hidden_state: (1, N_patches, d)  → mean-pool patches → (d,)
    embedding = out.last_hidden_state.squeeze(0).mean(dim=0).cpu().float().numpy()
    return embedding   # (d,)


def save_embedding(video_id: str, embedding: np.ndarray,
                   out_dir: str = OUT_DIR) -> Path:
    out_path = Path(out_dir) / "vjepa" / f"{video_id}.npy"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    np.save(str(out_path), embedding)
    return out_path


# ---------------------------------------------------------------------------
# CLI: run on all samples (or first N passed as argv[1])
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys as _sys

    manifest = Path("data/samples.json")
    with open(manifest) as fh:
        samples = json.load(fh)

    n = int(_sys.argv[1]) if len(_sys.argv) > 1 else len(samples)
    samples = samples[:n]

    from signals.mask_loader import load_video

    summary = []
    for i, sample in enumerate(samples):
        vid = sample["video_id"]
        out = Path(OUT_DIR) / "vjepa" / f"{vid}.npy"
        if out.exists():
            emb  = np.load(str(out))
            norm = float(np.linalg.norm(emb))
            print(f"[{i+1:02d}/{n}] {vid} – cached  d={emb.shape[0]}  norm={norm:.4f}")
            summary.append({"video_id": vid, "dim": emb.shape[0], "norm": round(norm, 4)})
            continue

        print(f"[{i+1:02d}/{n}] {vid} …", flush=True)
        frames, fps = load_video(sample["rgb_path"])

        emb      = embed_video(frames)
        norm     = float(np.linalg.norm(emb))
        out_path = save_embedding(vid, emb)

        fallback = _load_failed
        print(
            f"  model={_model_id or 'FALLBACK'}  "
            f"d={emb.shape[0]}  norm={norm:.4f}  "
            f"{'[FALLBACK]' if fallback else ''}  → {out_path}"
        )
        summary.append({
            "video_id": vid,
            "model":    _model_id or "fallback",
            "dim":      emb.shape[0],
            "norm":     round(norm, 4),
            "fallback": fallback,
        })

    # save manifest of embedding metadata
    sum_path = Path(OUT_DIR) / "vjepa" / "summary.json"
    sum_path.parent.mkdir(parents=True, exist_ok=True)
    with open(sum_path, "w") as fh:
        json.dump(summary, fh, indent=2)
    print(f"\nSummary → {sum_path}")
