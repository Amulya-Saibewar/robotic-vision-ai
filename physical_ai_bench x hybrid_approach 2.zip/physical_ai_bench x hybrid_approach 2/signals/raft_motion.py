"""
Optical-flow motion features for robot-task clips using RAFT-Large.
No SAM 2 inference — masks are pre-computed by mask_loader.

Sign convention for vertical flow (flow[1]):
  +v  → pixels moved downward  (arm lowering / object dropping)
  -v  → pixels moved upward    (arm lifting / object rising)

Divergence approximation: ∂u/∂x + ∂v/∂y via central finite differences,
evaluated only at pixels inside the mask.
"""

import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torchvision.models.optical_flow import raft_large, Raft_Large_Weights

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from config import DEVICE, OUT_DIR

# ---------------------------------------------------------------------------
# Module-level model load (once, on import)
# ---------------------------------------------------------------------------

_weights    = Raft_Large_Weights.DEFAULT
_model      = raft_large(weights=_weights).eval().to(DEVICE)
_transforms = _weights.transforms()

MAX_FRAMES = 32     # fallback cap if GPU OOM is signalled
LIFT_THRESHOLD = 0.5   # px/frame to call lift or place onset


# ---------------------------------------------------------------------------
# 1.  Per-pair optical flow
# ---------------------------------------------------------------------------

def _to_tensor(frame_hwc: np.ndarray) -> torch.Tensor:
    """HWC uint8 numpy → (3, H, W) uint8 torch, no device move yet."""
    return torch.from_numpy(frame_hwc).permute(2, 0, 1)   # (3, H, W)


def _pad_to_mult8(t: torch.Tensor) -> tuple[torch.Tensor, tuple[int, int, int, int]]:
    """Pad (B, 3, H, W) so H and W are multiples of 8.  Returns padded + pad tuple."""
    _, _, H, W = t.shape
    pad_h = (8 - H % 8) % 8
    pad_w = (8 - W % 8) % 8
    # F.pad order: (left, right, top, bottom)
    padding = (0, pad_w, 0, pad_h)
    return F.pad(t, padding, mode="replicate"), padding


def compute_flow(frame_t: np.ndarray, frame_t1: np.ndarray) -> torch.Tensor:
    """
    frame_t, frame_t1: HWC uint8 numpy arrays.
    Returns flow: (2, H, W) float32 on CPU (pixels per frame, u=x, v=y).
    """
    t0 = _to_tensor(frame_t)
    t1 = _to_tensor(frame_t1)
    x1, x2 = _transforms(t0, t1)           # (3, H, W) float, normalised
    x1 = x1.unsqueeze(0).to(DEVICE)        # (1, 3, H, W)
    x2 = x2.unsqueeze(0).to(DEVICE)

    orig_H, orig_W = x1.shape[2:]
    x1_pad, padding = _pad_to_mult8(x1)
    x2_pad, _       = _pad_to_mult8(x2)

    with torch.no_grad():
        flow_pad = _model(x1_pad, x2_pad)[-1]   # (1, 2, H_pad, W_pad)

    # strip padding, squeeze batch
    _, _, H_pad, W_pad = flow_pad.shape
    flow = flow_pad[:, :, :orig_H, :orig_W].squeeze(0).cpu()  # (2, H, W)
    return flow


# ---------------------------------------------------------------------------
# 2.  Per-frame feature helpers
# ---------------------------------------------------------------------------

def _mean_magnitude(flow_masked: torch.Tensor) -> float:
    """flow_masked: (2, H, W) already zeroed outside mask."""
    mag = flow_masked.norm(dim=0)   # (H, W)
    return float(mag.mean())


def _mean_vertical(flow_masked: torch.Tensor) -> float:
    return float(flow_masked[1].mean())


def _mean_divergence_in_mask(flow: torch.Tensor, mask: np.ndarray) -> float:
    """
    Central finite-difference divergence ∂u/∂x + ∂v/∂y, averaged over
    interior mask pixels.  Uses only positions with valid neighbours.
    """
    u = flow[0]   # (H, W)  horizontal
    v = flow[1]   # (H, W)  vertical

    # ∂u/∂x: central diff, valid cols 1..W-2
    du_dx = (u[:, 2:] - u[:, :-2]) / 2.0      # (H, W-2)
    # ∂v/∂y: central diff, valid rows 1..H-2
    dv_dy = (v[2:, :] - v[:-2, :]) / 2.0      # (H-2, W)

    # common interior: rows 1..H-2, cols 1..W-2
    div = du_dx[1:-1, :] + dv_dy[:, 1:-1]     # (H-2, W-2)

    # mask for the same interior
    mask_int = torch.from_numpy(mask[1:-1, 1:-1])
    n = mask_int.sum().item()
    if n == 0:
        return 0.0
    return float(div[mask_int].mean())


# ---------------------------------------------------------------------------
# 3.  Clip-level feature extraction
# ---------------------------------------------------------------------------

def extract_motion_features(
    frames: np.ndarray,   # (T, H, W, 3) uint8
    masks:  np.ndarray,   # (T, H, W) bool
    fps:    float,
    video_id: str = "",
) -> dict:
    """
    Compute per-frame and aggregate motion features inside the object mask.

    Returns a JSON-friendly dict with per-frame timeseries and scalars:
      mean_magnitude      list[float]  – mean ||flow|| inside mask per frame pair
      vertical_flow       list[float]  – mean v-component; -=up, +=down
      divergence          list[float]  – mean ∂u/∂x+∂v/∂y inside mask
      peak_vertical_drop  float        – max downward flow (most positive v)
      peak_time_s         float        – time of peak_vertical_drop
      lift_onset_s        float|null   – first t where vertical < -threshold
      place_onset_s       float|null   – first t after lift where vertical > +threshold
    """
    T = len(frames)

    # Downsample uniformly if needed (OOM guard or explicit cap)
    if T > MAX_FRAMES * 4:   # only kick in if really long
        idx = np.linspace(0, T - 1, MAX_FRAMES, dtype=int)
        frames = frames[idx]
        masks  = masks[idx]
        fps_eff = fps * (len(idx) - 1) / max(T - 1, 1)
    else:
        idx     = np.arange(T)
        fps_eff = fps

    T = len(frames)
    mag_ts, vert_ts, div_ts = [], [], []

    for t in range(T - 1):
        try:
            flow = compute_flow(frames[t], frames[t + 1])   # (2, H, W)
        except RuntimeError as exc:
            if "out of memory" in str(exc).lower():
                torch.cuda.empty_cache()
                # retry at half resolution
                h, w = frames.shape[1], frames.shape[2]
                f0 = frames[t, ::2, ::2]
                f1 = frames[t + 1, ::2, ::2]
                m_down = masks[t, ::2, ::2]
                flow_small = compute_flow(f0, f1)
                flow = F.interpolate(
                    flow_small.unsqueeze(0), size=(h, w), mode="bilinear",
                    align_corners=False,
                ).squeeze(0) * 2.0
                mask_t = m_down  # keep at downsampled size for this frame
                flow_masked = flow_small * torch.from_numpy(mask_t.astype(np.float32))
                mag_ts.append(_mean_magnitude(flow_masked))
                vert_ts.append(_mean_vertical(flow_masked))
                div_ts.append(_mean_divergence_in_mask(flow_small, m_down))
                continue
            raise

        mask_t      = masks[t]                                            # (H, W) bool
        flow_masked = flow * torch.from_numpy(mask_t.astype(np.float32)) # (2, H, W)

        mag_ts.append(_mean_magnitude(flow_masked))
        vert_ts.append(_mean_vertical(flow_masked))
        div_ts.append(_mean_divergence_in_mask(flow, mask_t))

    # --- aggregate scalars ---
    vert_arr   = np.array(vert_ts)
    times_s    = np.arange(len(vert_arr)) / fps_eff

    peak_idx              = int(np.argmax(vert_arr)) if len(vert_arr) else 0
    peak_vertical_drop    = float(vert_arr[peak_idx]) if len(vert_arr) else 0.0
    peak_time_s           = float(times_s[peak_idx]) if len(vert_arr) else 0.0

    lift_onset_s  = None
    place_onset_s = None

    lift_frames = np.where(vert_arr < -LIFT_THRESHOLD)[0]
    if len(lift_frames):
        lift_onset_s  = float(times_s[lift_frames[0]])
        place_frames  = np.where(
            (np.arange(len(vert_arr)) > lift_frames[0]) & (vert_arr > LIFT_THRESHOLD)
        )[0]
        if len(place_frames):
            place_onset_s = float(times_s[place_frames[0]])

    return {
        "video_id":           video_id,
        "n_frames":           T,
        "fps":                fps,
        "fps_effective":      fps_eff,
        "mean_magnitude":     [round(v, 4) for v in mag_ts],
        "vertical_flow":      [round(v, 4) for v in vert_ts],
        "divergence":         [round(v, 4) for v in div_ts],
        "peak_vertical_drop": round(peak_vertical_drop, 4),
        "peak_time_s":        round(peak_time_s, 4),
        "lift_onset_s":       round(lift_onset_s, 4) if lift_onset_s is not None else None,
        "place_onset_s":      round(place_onset_s, 4) if place_onset_s is not None else None,
    }


# ---------------------------------------------------------------------------
# 4.  Save helper
# ---------------------------------------------------------------------------

def save_motion_json(features: dict, out_dir: str = OUT_DIR) -> Path:
    out_path = Path(out_dir) / "motion" / f"{features['video_id']}.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as fh:
        json.dump(features, fh, indent=2)
    return out_path


# ---------------------------------------------------------------------------
# CLI: run on first 3 samples
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))

    from signals.mask_loader import load_video, load_masks_pkl, align

    manifest = Path("data/samples.json")
    with open(manifest) as fh:
        samples = json.load(fh)

    for sample in samples[:3]:
        vid = sample["video_id"]
        print(f"\n=== {vid} ===")

        frames, fps = load_video(sample["rgb_path"])
        masks       = load_masks_pkl(sample["sam2_pkl_path"])
        masks       = align(frames, masks)
        print(f"  frames {frames.shape}  masks {masks.shape}  fps={fps:.1f}")

        features = extract_motion_features(frames, masks, fps, video_id=vid)

        out_path = save_motion_json(features)
        print(f"  peak_vertical_drop : {features['peak_vertical_drop']:.4f} px/frame "
              f"at t={features['peak_time_s']:.2f}s")
        print(f"  lift_onset_s       : {features['lift_onset_s']}")
        print(f"  place_onset_s      : {features['place_onset_s']}")
        print(f"  mean magnitude (mean over time): "
              f"{np.mean(features['mean_magnitude']):.4f}")
        print(f"  saved → {out_path}")
