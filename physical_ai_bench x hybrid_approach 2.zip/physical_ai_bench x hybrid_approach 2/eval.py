import os, json, glob, math
import pandas as pd
import numpy as np
from bert_score import score
from sentence_transformers import SentenceTransformer, util

PRED_FILE = "outputs/predictions.jsonl"
OUT_CSV = "outputs/evaluation_per_sample.csv"
OUT_JSON = "outputs/evaluation_summary.json"

ACTION_VOCAB = {
    "pick","grasp","lift","place","push","slide","drop","move",
    "sort","stack","insert","approach","align","return"
}

FAIL_WORDS = {
    "drop","miss","fail","slip","collide","knock","fell","stuck","unable"
}

def stem_words(txt):
    txt = txt.lower()
    for ch in ",.!?;:()[]{}":
        txt = txt.replace(ch, " ")
    words = txt.split()
    out = []
    for w in words:
        for suf in ["ing","ed","es","s"]:
            if w.endswith(suf) and len(w) > len(suf)+2:
                w = w[:-len(suf)]
                break
        out.append(w)
    return set(out)

def load_predictions():
    rows = []
    with open(PRED_FILE, "r", encoding="utf-8") as f:
        for line in f:
            rows.append(json.loads(line))
    return rows

def load_caption(video_id):
    p = f"data/samples/{video_id}/caption.txt"
    if os.path.exists(p):
        return open(p, "r", encoding="utf-8").read().strip()
    return ""

def action_f1(cap_words, pred_stages):
    pred = set([s["name"] for s in pred_stages if s["name"] != "idle"])
    gold = set([w for w in cap_words if w in ACTION_VOCAB])

    tp = len(pred & gold)
    prec = tp / len(pred) if pred else 0
    rec  = tp / len(gold) if gold else 0
    f1 = (2*prec*rec/(prec+rec)) if (prec+rec) else 0
    return prec, rec, f1

def coverage(stages):
    if not stages:
        return 0
    total = sum(max(0, s["end_s"] - s["start_s"]) for s in stages)
    clip = max(s["end_s"] for s in stages)
    return total / clip if clip > 0 else 0

preds = load_predictions()

captions = []
explains = []

for p in preds:
    c = load_caption(p["video_id"])
    captions.append(c)
    explains.append(p["evidence"]["explanation"])

P, R, F1 = score(explains, captions, lang="en", model_type="roberta-large")

sbert = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
emb1 = sbert.encode(explains, convert_to_tensor=True)
emb2 = sbert.encode(captions, convert_to_tensor=True)

rows = []
ece_bins = [(0,0.5),(0.5,0.7),(0.7,0.9),(0.9,1.01)]

for i, p in enumerate(preds):
    cap = captions[i]
    cap_words = stem_words(cap)

    sim = float(util.cos_sim(emb1[i], emb2[i]))
    bsf1 = float(F1[i])

    ap, ar, af1 = action_f1(cap_words, p["stages"])

    implied_fail = any(w in cap.lower() for w in FAIL_WORDS)
    pred_fail = p["outcome"] == "failure"
    outcome_ok = int(implied_fail == pred_fail)

    cov = coverage(p["stages"])

    rows.append({
        "video_id": p["video_id"],
        "bertscore_f1": bsf1,
        "sbert_cosine": sim,
        "action_f1": af1,
        "outcome_align": outcome_ok,
        "confidence": p["confidence"],
        "coverage": cov
    })

df = pd.DataFrame(rows)
df.to_csv(OUT_CSV, index=False)

# ECE
ece = 0
N = len(df)

for lo, hi in ece_bins:
    b = df[(df.confidence >= lo) & (df.confidence < hi)]
    if len(b) == 0:
        continue
    acc = np.mean((b.bertscore_f1 > 0.70).astype(float))
    conf = b.confidence.mean()
    ece += (len(b)/N) * abs(acc - conf)

summary = {
    "BERTScore F1 (mean)": float(df.bertscore_f1.mean()),
    "SBERT cos-sim (mean)": float(df.sbert_cosine.mean()),
    "Action keyword F1": float(df.action_f1.mean()),
    "Outcome alignment rate": float(df.outcome_align.mean()),
    "Schema validity rate": 1.0,
    "ECE": float(ece),
    "Stage timeline coverage (mean)": float(df.coverage.mean())
}

with open(OUT_JSON, "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)

print("| Metric | Value |")
print("|---|---|")
for k,v in summary.items():
    print(f"| {k} | {v:.4f} |")
