"""
Configuration for the robot-task monitoring pipeline.
"""
import torch

# Dataset
DATASET_NAME = "shi-labs/physical-ai-bench-conditional-generation"
DATA_DIR     = "data"
OUT_DIR      = "outputs"
N_SAMPLES    = 20

# Hardware
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# Cosmos Reason 2 — using the 2B variant (Qwen3-VL-2B-Instruct backbone)
# Loaded with fp16 + sdpa attention — fits in ~5 GB GPU memory.
# Make sure you have:
#   1) huggingface-cli login   (with your HF token)
#   2) Accepted the license at https://huggingface.co/nvidia/Cosmos-Reason2-2B
#   3) transformers >= 4.57.0
COSMOS_MODEL = "nvidia/Cosmos-Reason2-2B"

# NIM API path is removed — local inference only.
USE_NIM_API = False
