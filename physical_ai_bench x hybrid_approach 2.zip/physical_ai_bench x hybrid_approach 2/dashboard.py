"""
Robot-Task Monitoring — Evaluation Dashboard
Streamlit app: evaluation metrics, signal charts, sample inspector, video player.

Run:  streamlit run dashboard.py --server.port 8501 --server.address 0.0.0.0
"""

import json
import glob
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

# ── page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Robot Task Monitor",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── data loading ─────────────────────────────────────────────────────────────

STAGE_KEYWORDS = {
    "approach": ["approach", "reach", "move toward", "position", "extend", "hover"],
    "align":    ["align", "position", "adjust", "orient"],
    "grasp":    ["grasp", "grip", "grab", "hold", "pick", "clamp", "take"],
    "lift":     ["lift", "raise", "elevat", "pick up", "suspend"],
    "move":     ["move", "transport", "carry", "transfer", "bring"],
    "place":    ["place", "put", "set down", "deposit", "lower"],
    "idle":     ["static", "stationary", "remain", "idle", "mostly static", "unchanged"],
}

STAGE_ORDER = ["approach", "align", "grasp", "lift", "move", "place", "idle"]
STAGE_COLORS = {
    "approach": "#4C9BE8", "align": "#F5A623", "grasp": "#7ED321",
    "lift": "#9B59B6",     "move": "#E74C3C",  "place": "#1ABC9C", "idle": "#95A5A6",
}


@st.cache_data
def load_all_data():
    samples  = json.load(open("data/samples.json"))
    preds    = {}
    motions  = {}
    depths   = {}

    for s in samples:
        vid = s["video_id"]
        pp = Path(f"outputs/predictions/{vid}.json")
        mp = Path(f"outputs/motion/{vid}.json")
        dp = Path(f"outputs/depth/{vid}.json")
        if pp.exists(): preds[vid]   = json.load(open(pp))
        if mp.exists(): motions[vid] = json.load(open(mp))
        if dp.exists(): depths[vid]  = json.load(open(dp))

    return samples, preds, motions, depths


def extract_gt_stages(caption: str) -> list[str]:
    t = caption.lower()
    return [s for s, kws in STAGE_KEYWORDS.items() if any(k in t for k in kws)] or ["idle"]


def infer_gt_outcome(caption: str) -> str:
    t = caption.lower()
    fail = sum(1 for w in ["fail","drop","miss","collid","stuck","unable","wrong","toppl"] if w in t)
    succ = sum(1 for w in ["success","complet","achiev","correct","properly","neatly","secur","accomplish"] if w in t)
    return "failure" if fail > succ else "success"


def stage_overlap(pred_stages: list[str], gt_stages: list[str]) -> float:
    """Jaccard similarity between predicted and GT stage sets."""
    p, g = set(pred_stages), set(gt_stages)
    if not p and not g: return 1.0
    return len(p & g) / len(p | g)


@st.cache_data
def build_eval_df(samples, preds):
    rows = []
    for s in samples:
        vid     = s["video_id"]
        caption = s["caption_text"]
        pred    = preds.get(vid, {})

        gt_stages  = extract_gt_stages(caption)
        gt_outcome = infer_gt_outcome(caption)

        pred_stages  = [st["name"] for st in pred.get("stages", [])]
        pred_outcome = pred.get("outcome", "unknown")
        confidence   = pred.get("confidence", 0.0)
        failure_cause = pred.get("failure_cause", "none")

        rows.append({
            "video_id":        vid,
            "gt_outcome":      gt_outcome,
            "pred_outcome":    pred_outcome,
            "correct_outcome": int(gt_outcome == pred_outcome),
            "gt_stages":       gt_stages,
            "pred_stages":     pred_stages,
            "stage_jaccard":   stage_overlap(pred_stages, gt_stages),
            "confidence":      confidence,
            "failure_cause":   failure_cause,
            "explanation":     pred.get("evidence", {}).get("explanation", ""),
            "n_pred_stages":   len(pred_stages),
            "n_gt_stages":     len(gt_stages),
        })
    return pd.DataFrame(rows)


# ── load ─────────────────────────────────────────────────────────────────────
samples, preds, motions, depths = load_all_data()
df = build_eval_df(samples, preds)

sample_map = {s["video_id"]: s for s in samples}

# ── sidebar ──────────────────────────────────────────────────────────────────
st.sidebar.title("🤖 Robot Task Monitor")
st.sidebar.markdown("**Navigation**")
page = st.sidebar.radio(
    "",
    ["📊 Evaluation Overview", "🔍 Sample Inspector", "📈 Signal Analysis"],
    label_visibility="collapsed",
)

# ═══════════════════════════════════════════════════════════════════════════
# PAGE 1 — EVALUATION OVERVIEW
# ═══════════════════════════════════════════════════════════════════════════
if page == "📊 Evaluation Overview":
    st.title("📊 Evaluation Overview")
    st.caption("Ground-truth derived from video captions · Predictions from Cosmos-Reason2")

    # ── top-level KPIs ──────────────────────────────────────────────────────
    acc = df["correct_outcome"].mean()
    mean_jaccard = df["stage_jaccard"].mean()
    mean_conf    = df["confidence"].mean()
    n_success_pred = (df["pred_outcome"] == "success").sum()
    n_failure_pred = (df["pred_outcome"] == "failure").sum()

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Outcome Accuracy",      f"{acc*100:.1f}%",  f"{df['correct_outcome'].sum()}/{len(df)} correct")
    c2.metric("Stage Jaccard (mean)",  f"{mean_jaccard:.3f}", "pred ∩ GT / pred ∪ GT")
    c3.metric("Mean Confidence",       f"{mean_conf:.2f}")
    c4.metric("Predicted Failures",    f"{n_failure_pred}", f"Success: {n_success_pred}")

    st.divider()

    # ── outcome comparison table ─────────────────────────────────────────────
    col_left, col_right = st.columns(2)

    with col_left:
        st.subheader("Outcome: GT vs Predicted")
        outcome_comp = df[["video_id", "gt_outcome", "pred_outcome", "correct_outcome", "confidence"]].copy()
        outcome_comp["✓"] = outcome_comp["correct_outcome"].map({1: "✅", 0: "❌"})
        outcome_comp["confidence"] = outcome_comp["confidence"].map("{:.2f}".format)
        st.dataframe(
            outcome_comp[["video_id", "gt_outcome", "pred_outcome", "✓", "confidence"]],
            use_container_width=True,
            hide_index=True,
        )

    with col_right:
        st.subheader("Outcome Distribution")
        oc = pd.DataFrame({
            "Source": ["Ground Truth", "Ground Truth", "Predicted", "Predicted"],
            "Outcome": ["success", "failure", "success", "failure"],
            "Count": [
                (df["gt_outcome"]   == "success").sum(),
                (df["gt_outcome"]   == "failure").sum(),
                (df["pred_outcome"] == "success").sum(),
                (df["pred_outcome"] == "failure").sum(),
            ]
        })
        fig_oc = px.bar(
            oc, x="Source", y="Count", color="Outcome",
            barmode="group",
            color_discrete_map={"success": "#2ECC71", "failure": "#E74C3C"},
            template="plotly_dark",
        )
        fig_oc.update_layout(margin=dict(t=10, b=10), height=300, legend_title_text="")
        st.plotly_chart(fig_oc, use_container_width=True)

    st.divider()

    # ── stage-level analysis ──────────────────────────────────────────────────
    st.subheader("Stage Coverage Analysis")

    col_a, col_b = st.columns(2)

    with col_a:
        # Jaccard per video
        fig_jac = px.bar(
            df.sort_values("stage_jaccard"),
            x="stage_jaccard", y="video_id",
            orientation="h",
            color="stage_jaccard",
            color_continuous_scale="RdYlGn",
            range_color=[0, 1],
            labels={"stage_jaccard": "Stage Jaccard", "video_id": ""},
            title="Stage Jaccard per Clip",
            template="plotly_dark",
        )
        fig_jac.update_layout(height=460, margin=dict(t=40, b=10), coloraxis_showscale=False)
        st.plotly_chart(fig_jac, use_container_width=True)

    with col_b:
        # Stage frequency: GT vs predicted
        gt_stage_counts   = {s: 0 for s in STAGE_ORDER}
        pred_stage_counts = {s: 0 for s in STAGE_ORDER}
        for _, row in df.iterrows():
            for s in row["gt_stages"]:   gt_stage_counts[s] = gt_stage_counts.get(s, 0) + 1
            for s in row["pred_stages"]: pred_stage_counts[s] = pred_stage_counts.get(s, 0) + 1

        stage_freq = pd.DataFrame({
            "Stage":     STAGE_ORDER,
            "GT":        [gt_stage_counts[s] for s in STAGE_ORDER],
            "Predicted": [pred_stage_counts[s] for s in STAGE_ORDER],
        })
        fig_sf = px.bar(
            stage_freq.melt(id_vars="Stage", var_name="Source", value_name="Count"),
            x="Stage", y="Count", color="Source", barmode="group",
            color_discrete_map={"GT": "#5B9BD5", "Predicted": "#ED7D31"},
            title="Stage Frequency: GT vs Predicted",
            template="plotly_dark",
        )
        fig_sf.update_layout(height=460, margin=dict(t=40, b=10), legend_title_text="")
        st.plotly_chart(fig_sf, use_container_width=True)

    st.divider()

    # ── confidence & failure cause ──────────────────────────────────────────
    col_c, col_d = st.columns(2)

    with col_c:
        st.subheader("Confidence Distribution")
        fig_conf = px.histogram(
            df, x="confidence", nbins=10,
            color="pred_outcome",
            color_discrete_map={"success": "#2ECC71", "failure": "#E74C3C"},
            title="Predicted Confidence by Outcome",
            template="plotly_dark",
            barmode="overlay",
        )
        fig_conf.update_traces(opacity=0.75)
        fig_conf.update_layout(height=300, margin=dict(t=40, b=10), legend_title_text="Outcome")
        st.plotly_chart(fig_conf, use_container_width=True)

    with col_d:
        st.subheader("Failure Cause Breakdown")
        fc = df[df["pred_outcome"] == "failure"]["failure_cause"].value_counts().reset_index()
        fc.columns = ["Cause", "Count"]
        if fc.empty:
            fc = pd.DataFrame({"Cause": ["none"], "Count": [len(df[df["pred_outcome"]=="failure"])]})
        fig_fc = px.pie(
            fc, names="Cause", values="Count",
            color_discrete_sequence=px.colors.qualitative.Set2,
            title="Predicted Failure Causes",
            template="plotly_dark",
            hole=0.4,
        )
        fig_fc.update_layout(height=300, margin=dict(t=40, b=10))
        st.plotly_chart(fig_fc, use_container_width=True)

    # ── signal correlation ─────────────────────────────────────────────────
    st.subheader("Signal vs Outcome Correlation")
    sig_rows = []
    for s in samples:
        vid = s["video_id"]
        m   = motions.get(vid, {})
        d   = depths.get(vid, {})
        p   = preds.get(vid, {})
        sig_rows.append({
            "video_id":        vid,
            "peak_drop":       m.get("peak_vertical_drop", 0),
            "activity_ratio":  m.get("activity_ratio", 0),
            "depth_gap_mm":    d.get("depth_gap_to_target_mm", 0),
            "min_g2o_dist":    d.get("min_gripper_to_object_distance", 0),
            "confidence":      p.get("confidence", 0),
            "outcome":         p.get("outcome", "unknown"),
        })
    sig_df = pd.DataFrame(sig_rows)

    fig_sig = make_subplots(
        rows=1, cols=3,
        subplot_titles=["Peak Vertical Drop", "Activity Ratio", "Depth Gap (mm)"],
    )
    for col_idx, (col_name, title) in enumerate(
        [("peak_drop","Peak Drop"), ("activity_ratio","Activity"), ("depth_gap_mm","Depth Gap mm")], 1
    ):
        for outcome, color in [("success", "#2ECC71"), ("failure", "#E74C3C")]:
            sub = sig_df[sig_df["outcome"] == outcome]
            fig_sig.add_trace(
                go.Box(y=sub[col_name], name=outcome, marker_color=color,
                       showlegend=(col_idx == 1)),
                row=1, col=col_idx,
            )
    fig_sig.update_layout(
        height=340, template="plotly_dark",
        margin=dict(t=40, b=10), boxmode="group",
        legend=dict(orientation="h", yanchor="bottom", y=1.05),
    )
    st.plotly_chart(fig_sig, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════
# PAGE 2 — SAMPLE INSPECTOR
# ═══════════════════════════════════════════════════════════════════════════
elif page == "🔍 Sample Inspector":
    st.title("🔍 Sample Inspector")
    st.caption("Select two samples to inspect side-by-side")

    video_ids = [s["video_id"] for s in samples]

    col_sel1, col_sel2 = st.columns(2)
    with col_sel1:
        vid1 = st.selectbox("Sample A", video_ids, index=1)
    with col_sel2:
        vid2 = st.selectbox("Sample B", video_ids, index=17)

    def render_sample(vid: str, col):
        s      = sample_map[vid]
        pred   = preds.get(vid, {})
        motion = motions.get(vid, {})
        depth  = depths.get(vid, {})

        with col:
            st.markdown(f"### {vid}")

            # Video
            rgb_path = Path(s["rgb_path"])
            if rgb_path.exists():
                with open(rgb_path, "rb") as vf:
                    st.video(vf.read())
            else:
                st.warning("Video file not found")

            # Prediction JSON
            with st.expander("📄 Prediction JSON", expanded=True):
                st.json(pred)

            # Stage timeline
            pred_stages = pred.get("stages", [])
            if pred_stages:
                clip_s = motion.get("n_frames", 121) / motion.get("fps", 30.0)
                fig_tl = go.Figure()
                for i, stg in enumerate(pred_stages):
                    fig_tl.add_trace(go.Bar(
                        x=[stg["end_s"] - stg["start_s"]],
                        base=[stg["start_s"]],
                        y=[stg["name"]],
                        orientation="h",
                        marker_color=STAGE_COLORS.get(stg["name"], "#888"),
                        name=stg["name"],
                        showlegend=False,
                        text=f"{stg['start_s']:.1f}–{stg['end_s']:.1f}s",
                        textposition="inside",
                    ))
                fig_tl.update_layout(
                    title="Predicted Stage Timeline",
                    xaxis_title="Time (s)", yaxis_title="",
                    xaxis_range=[0, clip_s],
                    height=200 + 30 * len(pred_stages),
                    margin=dict(t=40, b=10, l=60, r=10),
                    template="plotly_dark",
                    barmode="stack",
                )
                st.plotly_chart(fig_tl, use_container_width=True)

            # Outcome badge
            outcome = pred.get("outcome", "?")
            conf    = pred.get("confidence", 0)
            badge   = "🟢 SUCCESS" if outcome == "success" else "🔴 FAILURE"
            st.markdown(f"**Outcome:** {badge} &nbsp; **Confidence:** `{conf:.2f}`")

            if outcome == "failure":
                st.error(f"Failure cause: {pred.get('failure_cause', 'unknown')}")

            # Caption (ground truth)
            with st.expander("📝 Caption (Ground Truth)", expanded=False):
                st.write(s["caption_text"])

            # GT stages
            gt_stages = extract_gt_stages(s["caption_text"])
            st.markdown(f"**GT stages:** `{' → '.join(gt_stages)}`")
            pred_names = [st_["name"] for st_ in pred_stages]
            st.markdown(f"**Pred stages:** `{' → '.join(pred_names) if pred_names else 'none'}`")
            jac = stage_overlap(pred_names, gt_stages)
            st.progress(jac, text=f"Stage Jaccard: {jac:.2f}")

    col1, col2 = st.columns(2)
    render_sample(vid1, col1)
    render_sample(vid2, col2)


# ═══════════════════════════════════════════════════════════════════════════
# PAGE 3 — SIGNAL ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════
elif page == "📈 Signal Analysis":
    st.title("📈 Signal Analysis")
    st.caption("Per-clip RAFT optical flow and depth timeseries")

    vid_sel = st.selectbox(
        "Select clip",
        [s["video_id"] for s in samples],
        index=1,
    )

    m = motions.get(vid_sel, {})
    d = depths.get(vid_sel, {})
    p = preds.get(vid_sel, {})

    if not m:
        st.warning("No motion data found for this clip")
        st.stop()

    fps = m.get("fps", 30.0)
    T   = m.get("n_frames", 121)
    t_axis = [i / fps for i in range(T - 1)]  # T-1 pairs

    # ── motion signals ────────────────────────────────────────────────────
    st.subheader("RAFT Optical Flow Signals")

    mag  = m.get("mean_magnitude", [])
    vert = m.get("vertical_flow",  [])
    divg = m.get("divergence",     [])

    fig_motion = make_subplots(
        rows=3, cols=1,
        shared_xaxes=True,
        subplot_titles=["Mean Magnitude (px/frame)", "Vertical Flow (−=up, +=down)", "Divergence"],
        vertical_spacing=0.08,
    )
    for row_i, (data, color, name) in enumerate(
        [(mag, "#4C9BE8", "magnitude"),
         (vert, "#F5A623", "vertical"),
         (divg, "#7ED321", "divergence")], 1
    ):
        fig_motion.add_trace(
            go.Scatter(x=t_axis[:len(data)], y=data, mode="lines",
                       line=dict(color=color, width=1.5), name=name, showlegend=False),
            row=row_i, col=1,
        )
    # mark lift/place onsets
    for key, label, color in [
        ("lift_onset_s",  "Lift",  "cyan"),
        ("place_onset_s", "Place", "lime"),
    ]:
        val = m.get(key)
        if val is not None:
            for row_i in range(1, 4):
                fig_motion.add_vline(
                    x=val, line_dash="dot", line_color=color, line_width=1.5,
                    annotation_text=label if row_i == 1 else "",
                    annotation_position="top right",
                    row=row_i, col=1,
                )

    fig_motion.update_layout(
        height=520, template="plotly_dark",
        margin=dict(t=30, b=20),
        xaxis3_title="Time (s)",
    )
    st.plotly_chart(fig_motion, use_container_width=True)

    # ── depth signals ─────────────────────────────────────────────────────
    st.subheader("Depth Signals")

    odep = d.get("object_depth", [])
    g2o  = d.get("gripper_to_object_dist", [])
    t_dep = [i / fps for i in range(len(odep))]

    fig_depth = make_subplots(
        rows=2, cols=1, shared_xaxes=True,
        subplot_titles=["Object Depth (m)", "Gripper-to-Object Distance (m)"],
        vertical_spacing=0.12,
    )
    fig_depth.add_trace(
        go.Scatter(x=t_dep, y=odep, mode="lines",
                   line=dict(color="#9B59B6", width=1.5), showlegend=False),
        row=1, col=1,
    )
    fig_depth.add_trace(
        go.Scatter(x=t_dep[:len(g2o)], y=g2o, mode="lines",
                   line=dict(color="#E74C3C", width=1.5), showlegend=False),
        row=2, col=1,
    )
    # mark min g2o
    min_t = d.get("min_distance_time_s")
    if min_t is not None:
        for row_i in range(1, 3):
            fig_depth.add_vline(
                x=min_t, line_dash="dot", line_color="orange", line_width=1.5,
                annotation_text="min G2O" if row_i == 1 else "",
                annotation_position="top right",
                row=row_i, col=1,
            )

    fig_depth.update_layout(
        height=380, template="plotly_dark",
        margin=dict(t=30, b=20),
        xaxis2_title="Time (s)",
    )
    st.plotly_chart(fig_depth, use_container_width=True)

    # ── signal summary table ───────────────────────────────────────────────
    st.subheader("Signal Summary")
    summary_data = {
        "Signal":  ["peak_vertical_drop", "lift_onset_s", "place_onset_s",
                    "activity_ratio", "min_g2o_distance", "depth_gap_mm",
                    "depth_gradient_at_grasp"],
        "Value": [
            f"{m.get('peak_vertical_drop', 0):.4f} px/frame",
            str(m.get("lift_onset_s")),
            str(m.get("place_onset_s")),
            f"{m.get('activity_ratio', 0):.2f}",
            f"{d.get('min_gripper_to_object_distance', 0):.4f} m",
            f"{d.get('depth_gap_to_target_mm', 0):.1f} mm",
            f"{d.get('depth_gradient_at_grasp', 0):.4f} m/s",
        ],
    }
    st.dataframe(pd.DataFrame(summary_data), use_container_width=True, hide_index=True)

    # ── model prediction card ──────────────────────────────────────────────
    st.subheader("Model Prediction")
    colA, colB = st.columns([1, 2])
    with colA:
        outcome = p.get("outcome", "unknown")
        conf    = p.get("confidence", 0)
        st.metric("Outcome",    outcome.upper())
        st.metric("Confidence", f"{conf:.2f}")
        st.metric("Failure Cause", p.get("failure_cause", "none"))
    with colB:
        expl = p.get("evidence", {}).get("explanation", "No explanation.")
        st.info(expl)

# ── footer ───────────────────────────────────────────────────────────────────
st.sidebar.divider()
st.sidebar.caption(
    f"**Dataset:** 20 clips · RAFT + Depth + V-JEPA2 + Cosmos-Reason2\n\n"
    f"**Outcome accuracy:** {df['correct_outcome'].mean()*100:.1f}%\n\n"
    f"**Stage Jaccard:** {df['stage_jaccard'].mean():.3f}"
)
