"""Test with plain absolute path (no file:// prefix)."""
import json
import sys
import traceback
from pathlib import Path

import torch
import transformers

samples = json.load(open("data/samples.json"))
sample = samples[0]
vid = sample["video_id"]
abs_path = str(Path(sample["rgb_path"]).resolve())   # plain string, no file://

print(f"Testing on: {vid}")
print(f"Video path: {abs_path}")
print(f"Exists: {Path(abs_path).exists()}")

print("\n--- Loading model ---")
processor = transformers.AutoProcessor.from_pretrained("nvidia/Cosmos-Reason2-2B")
model = transformers.Qwen3VLForConditionalGeneration.from_pretrained(
    "nvidia/Cosmos-Reason2-2B",
    dtype=torch.float16,
    device_map="auto",
    attn_implementation="sdpa",
)
model.eval()
print("✓ Model loaded")

# CRITICAL: pass plain path, NOT file://...
messages = [
    {"role": "system", "content": [{"type": "text", "text": "You are a helpful assistant."}]},
    {"role": "user", "content": [
        {"type": "video", "video": abs_path, "fps": 4},   # <-- no file:// prefix
        {"type": "text", "text": "Describe what the robot does in one sentence."},
    ]},
]

print("\n--- apply_chat_template ---")
inputs = processor.apply_chat_template(
    messages,
    tokenize=True,
    add_generation_prompt=True,
    return_dict=True,
    return_tensors="pt",
    truncation=False,
    fps=4,
)
print("✓ Template applied; input_ids shape:", inputs["input_ids"].shape)

inputs = inputs.to(model.device)
print("\n--- Generating ---")
with torch.no_grad():
    out_ids = model.generate(**inputs, max_new_tokens=256, do_sample=False)
prompt_len = inputs["input_ids"].shape[1]
text = processor.decode(out_ids[0, prompt_len:], skip_special_tokens=True)

print("\n=== MODEL OUTPUT ===")
print(text)
print("====================")
print("\n✓ SUCCESS — Cosmos works end-to-end!")
