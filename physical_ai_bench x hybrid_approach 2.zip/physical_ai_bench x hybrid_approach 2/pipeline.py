"""
End-to-end pipeline orchestrator for the 20-sample run.
Loads precomputed sam2.pkl masks + depth.npz, runs RAFT + V-JEPA 2 + Cosmos.
"""
from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path

import numpy as np
from tqdm import tqdm

from config import OUT_DIR
from signals.mask_loader   import align, load_masks_pkl, load_video
from signals.raft_motion   import extract_motion_features
from signals.depth_features import load_depth_npz, extract_depth_features
from signals.vjepa_embed   import embed_video
from reasoning.cosmos_runner import run_cosmos


def main():
    # ---- Setup ----
    out_dir = Path(OUT_DIR)
    (out_dir / "motion").mkdir(parents=True, exist_ok=True)
    (out_dir / "depth").mkdir(parents=True, exist_ok=True)
    (out_dir / "vjepa").mkdir(parents=True, exist_ok=True)
    (out_dir / "predictions").mkdir(parents=True, exist_ok=True)
    (out_dir / "cosmos").mkdir(parents=True, exist_ok=True)

    err_log = out_dir / "errors.log"
    err_log.write_text("")  # truncate

    # ---- Load sample manifest ----
    manifest = Path("data/samples.json")
    with open(manifest) as fh:
        samples = json.load(fh)
    print(f"\n[pipeline] processing {len(samples)} samples\n")

    predictions = []
    n_ok, n_err = 0, 0

    for sample in tqdm(samples, desc="samples"):
        vid = sample["video_id"]
        try:
            # --- 1. Load video frames + masks (no SAM2 model run) ---
            frames, fps = load_video(sample["rgb_path"])
            masks       = load_masks_pkl(sample["sam2_pkl_path"])
            masks       = align(frames, masks)

            # --- 2. RAFT motion features ---
            motion_path = out_dir / "motion" / f"{vid}.json"
            if motion_path.exists():
                with open(motion_path) as fh:
                    motion = json.load(fh)
            else:
                motion = extract_motion_features(frames, masks, fps)
                motion_path.write_text(json.dumps(motion, indent=2))

            # --- 3. Depth features (read .npz directly) ---
            depth_path_json = out_dir / "depth" / f"{vid}.json"
            if depth_path_json.exists():
                with open(depth_path_json) as fh:
                    depth = json.load(fh)
            else:
                depth_maps, unit = load_depth_npz(sample["depth_npz_path"])
                depth = extract_depth_features(depth_maps, masks, fps)
                depth["unit"] = unit
                depth_path_json.write_text(json.dumps(depth, indent=2))

            # --- 4. V-JEPA 2 embedding ---
            vjepa_path = out_dir / "vjepa" / f"{vid}.npy"
            if vjepa_path.exists():
                e_V = np.load(str(vjepa_path))
            else:
                e_V = embed_video(frames)
                np.save(str(vjepa_path), e_V)
            vjepa_norm = float(np.linalg.norm(e_V))

            # --- 5. Cosmos Reason 2 → JSON ---
            pred = run_cosmos(sample, motion, depth, vjepa_norm, frames, fps)
            predictions.append(pred.model_dump())
            n_ok += 1

        except Exception as exc:
            n_err += 1
            tb = traceback.format_exc()
            with open(err_log, "a") as fh:
                fh.write(f"\n=== {vid} ===\nstage: pipeline\n{tb}\n")
            tqdm.write(f"  [pipeline] ✗ {vid}: {exc}")
            continue

    # ---- Concatenate predictions ----
    out_jsonl = out_dir / "predictions.jsonl"
    with open(out_jsonl, "w") as fh:
        for p in predictions:
            fh.write(json.dumps(p) + "\n")

    print(f"\n{'='*70}")
    print(f"  Pipeline complete")
    print(f"  ✓ {n_ok} succeeded   ✗ {n_err} errored")
    print(f"  → predictions: {out_jsonl}  ({len(predictions)} lines)")
    if n_err:
        print(f"  → errors:      {err_log}")
    print('=' * 70)


if __name__ == "__main__":
    main()
